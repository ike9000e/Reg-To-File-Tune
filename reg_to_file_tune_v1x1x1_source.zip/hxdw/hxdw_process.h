#pragma once
#include <vector>
#include <string>
#include <algorithm>
#include <functional>
#include <inttypes.h>
struct tagPROCESSENTRY32;
typedef struct tagPROCESSENTRY32 PROCESSENTRY32;
#ifdef _WIN64
	typedef struct _IMAGE_NT_HEADERS64 IMAGE_NT_HEADERS;
#else
	typedef struct _IMAGE_NT_HEADERS IMAGE_NT_HEADERS;
#endif
struct HxdwModOnEnum; struct HxdwMSectEnum;


size_t      hxdw_GetModuleBaseAddress( uint32_t uProcId, const char* szModName );
size_t      hxdw_GetModuleSectionVAddress( void* hMod, const char* szSecName );
bool        hxdw_EnumerateProcessModules( uint32_t pid2, std::function<bool(const HxdwModOnEnum&)> calb2 );
bool        hxdw_IsExistingProcess( uint32_t pid2 );
std::string hxdw_GetProcessBinaryPath( uint32_t pid2 );
bool        hxdw_EnumerateModuleSections( void* hMod, std::function<bool( const HxdwMSectEnum& inp )> calb2 );
void*       hxdw_GetPtrGivenInSectionOffset( uint32_t uPID, const char* szModName, const char* szSecName, size_t uInSectionOffset );
void        hxdw_EnumerateSystemProcesses( std::function<bool( const PROCESSENTRY32& inp )> calb2 );
auto        hxdw_GetParentProcessIdentifiers( uint32_t uPID ) -> std::vector<uint32_t>;
auto        hxdw_GetProcessEntryStruct( uint32_t pid_ ) -> PROCESSENTRY32;
auto        hxdw_GetProcessThreads( uint32_t pid_ ) -> std::vector<uint32_t>;
void*       hxdw_FindParentCMDWindow( uint32_t pid_, uint32_t* pPidOu, const char* flags2 );
void*       hxdw_FindChildCMDWindow( uint32_t pid_, uint32_t* pPidOu, const char* flags2 );
int32_t     hxdw_GetBinaryType3( const char* szFileName, const char* flags2_ );
bool        hxdw_GetPEImageNtHeadersStruct2( const char* szFileName, std::function<void( const IMAGE_NT_HEADERS* inp )> calb2, std::string* err_ );

/// Module/Dll information used wih hxdw_EnumerateProcessModules().
struct HxdwModOnEnum{
	void*       hDll = 0;   //HMODULE
	std::string srPath;
};
struct HxdwMSectEnum {
	const char* szName;
	uint64_t uVirtualAddress;
	uint64_t uPointerToRawData;
	uint64_t uSizeOfRawData;
};

