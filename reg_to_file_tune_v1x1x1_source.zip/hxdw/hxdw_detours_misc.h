#pragma once
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <inttypes.h>
struct HxdwEnumImportsDTO; struct HxdwAttachSpec;
struct HxdwDetachSpec;

bool        hxdw_GetPEFileImportDlls( const char* szFname, std::vector<std::string>* outp, std::string* err2 );
bool        hxdw_GetPEFileImportFunctions( const char* szFname, std::function<bool(const HxdwEnumImportsDTO&)> calb2, const char* flags2, std::string* err2 );
bool        hxdw_GetPEExports( const char* pathname, std::vector<std::string>& outp );
std::string hxdw_DetoursErrorToString( long errorcode );
long        hxdw_DetourAttach( void* pAddress, void** ppOrigCall, void* pDetour, long(__stdcall*pDetourAttach)(void**,void*) );
long        hxdw_DetourAttach3( void* hDll, const char* szDllName, const char* szProcName, void** ppOrigCall, void* pDetour, size_t, long(__stdcall*pDetourAttach)(void**,void*) );
long        hxdw_DetourAttachMulti( const std::vector<HxdwAttachSpec>& aAttachSpecs, bool bWithTransaction );
long        hxdw_DetourDetachMulti( const std::vector<HxdwDetachSpec>& aDetachSpecs, bool bWithTransaction );

struct HxdwEnumImportsDTO {
	void*       hModule;
	std::string srDllName;
	int         nOrdinal;   ///< if the import is by ordinal, set to value greater or equal 0, otherwise -1.
	std::string srFuncName;
	void**      ppvFunc;    ///< See Detours docs DetourEnumerateImportsEx() and DetourImportFuncCallbackEx().
};
struct HxdwAttachSpec{
	void* pAddress;
	void** ppOrigCall;
	void* pDetour;
};
struct HxdwDetachSpec{
	void** ppOrigCall;
	void* pDetour;
};
/**
	Setups Deturs API hook using DetourAttach().
	\code
		// Example:
		mdp_SetupDtrHook<GetTickCount_t>(
				&MdpData2->fnOgGetTickCount,
				mdp_GetTickCount,
				MdpData2->hKernel32, "GetTickCount" );
	\endcode
*/
template<class Tft, class Thmodule = HMODULE>
void hxdw_SetupDetoursHook( Tft** fnOgApi, Tft* fnFilterApi, void* hDll4, const char* szApiFunctName )
{
	assert( fnOgApi );
	//assert( !(*fnOgApi) );
	assert( hDll4 );
	*fnOgApi = (Tft*) GetProcAddress( (Thmodule)hDll4, szApiFunctName );  //eg. "GetTickCount"
	assert( *fnOgApi );
	DetourAttach( &(PVOID&)(*fnOgApi), fnFilterApi );
}
