#pragma once
#include <vector>
#include <string>
#include <algorithm>
#include <functional>
#include <inttypes.h>
#include "hxdw_utils.h"


/**
	Manager for detoured Winapi functions.
	Ie. this is a singleton. For the most part, implementation of the detoured
	functions is keept elsewhere.
*/
struct PrfApiDtrMgr{
	PrfApiDtrMgr();
	bool addFuncRefByName2( const char* szWinapiName, const char* flags2 );
	bool unfoldApiDetours();
	bool foldApiDetours();
	auto findOriginalFunc2( void* lpFuncDtrTo3 ) -> HxdwQuad2<bool,void*>;
private:
	struct SKnowApi2;
	struct SKnowDll2;
	auto findApiByName2( const char* szWinapiName ) -> HxdwQuad2<bool, std::vector<SKnowDll2>::iterator, std::vector<SKnowApi2>::iterator, int>;
	auto arrangeSingleApiDetour( const std::string& winapiName, void* hSysDll ) -> HxdwQuad2<bool,LRESULT>;
	void updateSysDllHandles();
private:
	struct SKnowDll2{
		std::string             srDllName2;
		void*                   hSysDll2 = 0;
		std::vector<SKnowApi2>  aApis2;
	};
	struct SKnowApi2{
		std::string   srFuncName2;
		size_t        uNumRefs = 0;
		bool          bUnfolded2 = 0L;
	};
	struct SApiPointers2{
		std::string   srFuncName4;
		void*         lpFuncDtrTo2 = nullptr;
		void*         lpOriginal2 = nullptr;
	};
private:
	static const std::vector<SKnowDll2> mDllInfos2;
	std::vector<SKnowDll2> mDllInfos3;
	static const std::vector<SApiPointers2> mPointerApis2;
	std::vector<SApiPointers2> mPointerApis3;
};
