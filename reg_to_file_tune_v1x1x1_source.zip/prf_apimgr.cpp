#include "prf_apimgr.h"
#include <windows.h>
#include <assert.h>
#include "detours.h"
#include "hxdw_process.h"
#include "hxdw_detours_misc.h"
#include "prf_regfunc.h"

PrfApiDtrMgr::PrfApiDtrMgr()
	: mDllInfos3( mDllInfos2 )
	, mPointerApis3( mPointerApis2 )
{
}
const std::vector<PrfApiDtrMgr::SKnowDll2> PrfApiDtrMgr::mDllInfos2 = {
/*	{"user32.dll", 0, {
		//	{"PeekMessageA",},
		//	{"PeekMessageW",},
		},
	},//*/
	{"advapi32.dll", 0, {
			{"RegCreateKeyExA", 0u, 0L,},
			{"RegCreateKeyExW", 0u, 0L,},
			{"RegOpenKeyExA", 0u, 0L,},
			{"RegOpenKeyExW", 0u, 0L,},
			{"RegSetValueExA", 0u, 0L,},
			{"RegSetValueExW", 0u, 0L,},
			{"RegQueryValueExA", 0u, 0L,},
			{"RegQueryValueExW", 0u, 0L,},
			{"RegCloseKey", 0u, 0L,},
			{"RegEnumKeyExA", 0u, 0L,},
			{"RegEnumKeyExW", 0u, 0L,},
			{"RegDeleteValueA", 0u, 0L,},
			{"RegDeleteValueW", 0u, 0L,},
			{"RegDeleteKeyA", 0u, 0L,},
			{"RegDeleteKeyW", 0u, 0L,},
			{"RegQueryValueA", 0u, 0L,},
			{"RegQueryValueW", 0u, 0L,},
			{"RegOpenKeyA", 0u, 0L,},
			{"RegOpenKeyW", 0u, 0L,},
			{"RegDeleteKeyExA", 0u, 0L,},
			{"RegDeleteKeyExW", 0u, 0L,},
			{"RegCreateKeyA", 0u, 0L,},
			{"RegCreateKeyW", 0u, 0L,},
			{"RegSetValueA", 0u, 0L,},
			{"RegSetValueW", 0u, 0L,},
			{"RegEnumKeyA", 0u, 0L,},
			{"RegEnumKeyW", 0u, 0L,},
		},
	},
};
const std::vector<PrfApiDtrMgr::SApiPointers2> PrfApiDtrMgr::mPointerApis2 = {
	{"RegCreateKeyExA", Prf_RegCreateKeyExA, nullptr,},
	{"RegCreateKeyExW", Prf_RegCreateKeyExW, nullptr,},
	{"RegOpenKeyExA", Prf_RegOpenKeyExA, nullptr,},
	{"RegOpenKeyExW", Prf_RegOpenKeyExW, nullptr,},
	{"RegSetValueExA", Prf_RegSetValueExA, nullptr,},
	{"RegSetValueExW", Prf_RegSetValueExW, nullptr,},
	{"RegQueryValueExA", Prf_RegQueryValueExA, nullptr,},
	{"RegQueryValueExW", Prf_RegQueryValueExW, nullptr,},
	{"RegCloseKey", Prf_RegCloseKey, nullptr,},
	{"RegEnumKeyExA", Prf_RegEnumKeyExA, nullptr,},
	{"RegEnumKeyExW", Prf_RegEnumKeyExW, nullptr,},
	{"RegDeleteValueA", Prf_RegDeleteValueA, nullptr,},
	{"RegDeleteValueW", Prf_RegDeleteValueW, nullptr,},
	{"RegDeleteKeyA", Prf_RegDeleteKeyA, nullptr,},
	{"RegDeleteKeyW", Prf_RegDeleteKeyW, nullptr,},
	{"RegQueryValueA", Prf_RegQueryValueTAW<char>, nullptr,},
	{"RegQueryValueW", Prf_RegQueryValueTAW<wchar_t>, nullptr,},
	{"RegOpenKeyA", Prf_RegOpenKeyA, nullptr,},
	{"RegOpenKeyW", Prf_RegOpenKeyW, nullptr,},
	{"RegDeleteKeyExA", Prf_RegDeleteKeyExA, nullptr,},
	{"RegDeleteKeyExW", Prf_RegDeleteKeyExW, nullptr,},
	{"RegCreateKeyA", Prf_RegCreateKeyA, nullptr,},
	{"RegCreateKeyW", Prf_RegCreateKeyW, nullptr,},
	{"RegSetValueA", Prf_RegSetValueA, nullptr,},
	{"RegSetValueW", Prf_RegSetValueW, nullptr,},
	{"RegEnumKeyA", Prf_RegEnumKeyA, nullptr,},
	{"RegEnumKeyW", Prf_RegEnumKeyW, nullptr,},
};
HxdwQuad2<bool,void*>
PrfApiDtrMgr::findOriginalFunc2( void* lpFuncDtrTo3 )
{
	std::vector<SApiPointers2>::iterator ir2;
	ir2 = std::find_if( mPointerApis3.begin(), mPointerApis3.end(),
		[&]( const SApiPointers2& inp )->bool{
			return lpFuncDtrTo3 == inp.lpFuncDtrTo2;
	});
	if( ir2 != mPointerApis3.end() ){
		assert( ir2->lpOriginal2 );
		return { 1L, ir2->lpOriginal2,};
	}
	return { 0L, nullptr, 0,0,};
}

HxdwQuad2<bool, std::vector<PrfApiDtrMgr::SKnowDll2>::iterator, std::vector<PrfApiDtrMgr::SKnowApi2>::iterator, int>
PrfApiDtrMgr::
findApiByName2( const char* szWinapiName )
{
	assert( szWinapiName && *szWinapiName );
	assert( !mDllInfos3.empty() );
	assert( !mDllInfos3[0].aApis2.empty() );
	auto ir3 = mDllInfos3[0].aApis2.end();
	auto ir2 = std::find_if( mDllInfos3.begin(), mDllInfos3.end(),
		[&]( SKnowDll2& in2 )->bool{
			ir3 = std::find_if( in2.aApis2.begin(), in2.aApis2.end(),
				[&]( SKnowApi2& in3 )->bool{
					return in3.srFuncName2 == szWinapiName;
			});
			return ir3 != in2.aApis2.end();
	});
	if( ir2 == mDllInfos3.end() ){
		return { 0L, ir2, ir3, 0,};
	}
	assert( ir3 != ir2->aApis2.end() );
	return { 1L, ir2, ir3, 0,};
}
bool PrfApiDtrMgr::
addFuncRefByName2( const char* szWinapiName, const char* flags2 )
{
	auto res2 = findApiByName2( szWinapiName );
	if( !*res2 ){
		bool bAssertOk = !!std::strchr( flags2, 'a');
		hxdw_StdPrint3("PRF: ERROR: Function \x22%a\x22 not found. Not supported API [XOVkZE]\n", {
				szWinapiName,});
		if( bAssertOk ){
			assert(!"Function not found. Not supported API [mF2qw0]");
		}
		return 0L;
	}
	res2.third->uNumRefs += 1;
	return 1L;
}
HxdwQuad2<bool,LRESULT>
PrfApiDtrMgr::arrangeSingleApiDetour( const std::string& srFuncName3, void* hSysDll )
{
	assert( !srFuncName3.empty() );
	assert( hSysDll );
	std::vector<SApiPointers2>::iterator ir2;
	ir2 = std::find_if( mPointerApis3.begin(), mPointerApis3.end(),
		[&]( const SApiPointers2& inp )->bool{
			// Eg.: srFuncName3: "RegOpenKeyExA"
			return srFuncName3 == inp.srFuncName4;
	});
	if( ir2 == mPointerApis3.end() ){
		return { 0L, ERROR_INVALID_DATA,};
	}
	assert( ir2->lpFuncDtrTo2 );
	assert( srFuncName3 == ir2->srFuncName4 );
	assert( !ir2->lpOriginal2 );
	LRESULT rs2;
	rs2 = hxdw_DetourAttach3( hSysDll, nullptr, srFuncName3.c_str(),
			&ir2->lpOriginal2, ir2->lpFuncDtrTo2, 0, DetourAttach );
	if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
		return { 0L, rs2,};
	}
	assert( ir2->lpOriginal2 );
	return { 1L, ERROR_SUCCESS,};
}
void PrfApiDtrMgr::updateSysDllHandles()
{
	for( auto a = mDllInfos3.begin(); a != mDllInfos3.end(); ++a ){
		a->hSysDll2 = 0;
	}
	//std::for_each( mDllInfos3.begin(), mDllInfos3.end(),
	//	[&]( SKnowDll2& in2 ){
	//		//in2.hSysDll2 = 0;
	//});
	hxdw_EnumerateProcessModules( 0, [&]( const HxdwModOnEnum& inp )->bool{
		assert( inp.hDll );
		assert( inp.hDll != INVALID_HANDLE_VALUE );
		const auto srSysDllFNm = hxdw_SplitExt( hxdw_SplitPath( inp.srPath ).second ).first;
		assert( !srSysDllFNm.empty() );
		std::find_if( mDllInfos3.begin(), mDllInfos3.end(),
			[&]( SKnowDll2& in2 )->bool{
				if( !in2.hSysDll2 ){
					const auto fname2 = hxdw_SplitExt( in2.srDllName2 ).first;
					assert( !fname2.empty() );
					bool rs2;
					rs2 = hxdw_StrCmpOpt3( srSysDllFNm.c_str(), fname2.c_str(), -1, "i" );
					if( !rs2 ){
						in2.hSysDll2 = inp.hDll;
						return 1L; // 1: end search.
					}
				}
				return 0L; // 0: continue search.
		});
		return 1L;  // 1: continue enumeration.
	});
}
bool PrfApiDtrMgr::unfoldApiDetours()
{
	updateSysDllHandles();
	//
	size_t uCntSuccDtrdFnc = 0, uCntNumFailed = 0, uNumUnreferenced = 0;
	for( auto ir2 = mDllInfos3.begin(); ir2 != mDllInfos3.end(); ++ir2 ){
		for( auto ir3 = ir2->aApis2.begin(); ir3 != ir2->aApis2.end(); ++ir3 ){
			if( ir3->uNumRefs ){
				assert( !ir3->bUnfolded2 );
				auto res2 = arrangeSingleApiDetour( ir3->srFuncName2.c_str(), ir2->hSysDll2 );
				if( !*res2 ){
					hxdw_StdPrint3("PRF: ERROR: Detouring \x22%s\x22 failed. Code:[%a:%a] [9HUS0N]\n",{
						ir3->srFuncName2,
						(int)+res2,
						hxdw_DetoursErrorToString( +res2 ),});
					uCntNumFailed += 1;
				}else{
					uCntSuccDtrdFnc += 1;
					ir3->bUnfolded2 = 1L;
				}
			}else{
				uNumUnreferenced += 1;
			}
		}
	}
	hxdw_StdPrint3("PRF: Detoured %a of %a Winapi functions. Skipped: %a. Failed: %a.\n", {
		(int64_t)uCntSuccDtrdFnc,
		(int64_t)mPointerApis3.size(),
		(int64_t)uNumUnreferenced,
		(int64_t)uCntNumFailed,});
	return 1L;
}
/// Folds, disables unfolded API detours,
/// enabled prviously with unfoldApiDetours() call.
bool PrfApiDtrMgr::foldApiDetours()
{
	return 1L;
}
