#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
//#define _USING_V110_SDK71_ 1
#include <windows.h>
//#include <string>
//#include <vector>
#include "hxdw_utils.h"

struct hxdw_IniData2;
struct PrfRegHKTracker;
struct PrfApiDtrMgr;
template<class TCh> struct PrfRegEnumKeyExParams;

bool        PrfRegIsPredefinedRootKey( HKEY hKeyInp );
std::string PrfRegRootKeyToStr( HKEY hKeyInp, const char* flags2 );
std::string PrfRegDataTypeToStr2( DWORD dwType2, const char* flags2 );
auto        PrfRegStrToDataType2( const char* szDataTyoe, const char* flags2 ) -> HxdwQuad2<bool,DWORD,int,int>;
std::string PrfRegDataToStr2( DWORD dwType, const uint8_t* lpData, DWORD cbData );
auto        PrfRegStrToData2( const char* inp, DWORD dwType, uint8_t* lpData, DWORD* lpIODataSize ) -> HxdwQuad2<bool,LONG,int,int>;
;           template<class TCh>
bool        PrfRegValidateRegEnumKeyExParams( const PrfRegEnumKeyExParams<TCh>& inp );

struct PrfData{
	PrfData();
	~PrfData();
	std::string        srAppName = "Reg To File Tune DLL";
	std::string        srSelfDllPathName, srSelfDllBaseName, srSelfDllDirName;
	std::string        srSelfExePathName, srSelfExeBaseName;
	std::string        srIniPathName, srDbsIniPathName;
	hxdw_IniData2&     ini2;
	PrfRegHKTracker&   rt2;
	PrfApiDtrMgr&      am2;
	bool               bHandleRundll32 = 0L;
	size_t             nCalls2 = 0, nCalls3 = 0, nCalls4 = 0, nCalls5 = 0;
	size_t             eSaveINIStrategy = 1;//PRF_ESIS_OnRegApiClose = 0x1
	size_t             eConsoleIOFixMode = 0; //0: none, 1: alloc-console, 2: env-var., 3|4: Find CMD parent|child.

	bool bShowRegOpeners = 0L;
	bool bShowRegSetters = 0L;
	bool bShowRegGetters = 0L;
	bool bShowRegClose = 0L;
	bool bShowRegEnumerators = 0L;
	bool bShowRegDeleters = 0L;
};
extern PrfData* Prf2;

template<class TCh>
struct PrfRegEnumKeyExParams{
	TCh* lpName;
	DWORD* lpcbName;
	TCh* lpClass;
	DWORD* lpcbClass;
};

/// Flags for PrfRegHKTracker::addKeyForTracking2().
enum : size_t{
	PRF_ETrkOnCreateKey = 0x1,
};
struct PrfCrKey2{
	std::string srKPath3;
	DWORD*      lpdwDisposition2 = nullptr;
	HKEY*       phKeyOut2 = nullptr;//PHKEY
};
struct PrfOpenKey2{
	std::string srKPath3;
	HKEY*       phKeyOut2 = nullptr;//PHKEY
};
struct PrfSetVal2{
	HKEY            hKey = 0;
	const char*     szValueName = nullptr;
	DWORD           dwType = 0;
	const uint8_t*  lpData = nullptr;
	DWORD           cbData = 0;
	bool            bValCanBePath = 0;
};
struct PrfGetVal2{
	HKEY            hKey = 0;
	const char*     szValueName = nullptr;
	DWORD*          lpType = nullptr;
	uint8_t*        lpData = nullptr;
	DWORD*          lpcbData = nullptr;  //size of data.
};
struct PrfDelKey2{
	HKEY            hKey = 0;
	const char*     lpSubKey = nullptr;
	std::string     srKPath3;
};
struct PrfEnumKey2{
	HKEY            hKey = 0;
	DWORD           dwIndex = 0;
	char*           lpName = nullptr;
	DWORD*          lpcbName = nullptr;
};

struct PrfRegHKTracker
{
	PrfRegHKTracker();
	~PrfRegHKTracker();
	bool setDatabaseINIFile( const char* szIniFName );
	bool addKeyDetour2( const char* szAbsKPath );
	bool addKeyForTracking2( HKEY hKeyParent, const char* szSubKey2, HKEY hKeyOpened, size_t flags3, std::string* err2, std::string* srFullPathOu );
	auto testPathForDetour( HKEY hKeyParent, const char* szSubKey2, std::string* err_, std::string* srFullPathOu )const -> HxdwQuad2<bool,bool>;
	auto isKeyTracked2( HKEY hKey )const -> HxdwQuad2<bool,bool,std::string,int>;

	auto createRegKey2( const PrfCrKey2& inp ) -> HxdwQuad2<bool,LONG,int,int>;
	auto openRegKey2( const PrfOpenKey2& inp ) -> HxdwQuad2<bool,LONG,int,int>;
	auto closeRegKeyIf2( HKEY hKey, const char* flags2 ) -> HxdwQuad2<bool,bool,std::string>;
	auto setRegValue2( const PrfSetVal2& inp ) -> HxdwQuad2<bool,LONG,int,int>;
	auto getRegValue2( const PrfGetVal2& inp ) -> HxdwQuad2<bool,LONG,int,int>;
	auto deleteRegKey2( const PrfDelKey2& inp ) -> HxdwQuad2<bool,LONG,int,int>;
	auto getRegKeyEnumInfoAtIndex2( const PrfEnumKey2& inp ) -> HxdwQuad2<bool,LONG>;
private:
	struct STrckd;
	HKEY addOwnKeyForTracking2( const char* szKPath2 );
	auto findKey2( HKEY hKey ) -> std::vector<STrckd>::iterator;
	auto isKeyVarnameByToken( const char* keyname2 )const -> HxdwQuad2<bool,size_t,int,int>;
	auto getKeyVarnameIndexIfAny( const char* keyname2 )const -> HxdwQuad2<bool,size_t,int,int>;
	bool saveINIFile();
private:
	struct STrckd{
		HKEY        hKeyOpened2 = 0;
		HKEY        hKeyParent2 = 0;
		bool        bIsPredefined2 = 0L;  //eg. if is 'HKEY_CURRENT_USER'.
		bool        bDetoured3 = 0L;
		std::string srKeyPath2;
	};
	const std::string         mVnToken2 = "var2";
	std::vector<std::string>  mDPaths2;
	std::vector<STrckd>       mATracked;
	hxdw_IniData2&            ini3;
	std::string               mIniFName;
	size_t                    mLastOwnKeyVal = 0xBFFFFF;
};

enum : size_t{
	PRF_ESIS_OnRegApiClose = 0x1,
	PRF_ESIS_OnProcApiExit = 0x2,
};
