#include "prf_utils.h"
#include <assert.h>
//#include <cctype>  //std::tolower()
#include "detours.h"
#include "hxdw_process.h"
#include "hxdw_detours_misc.h"
#include "prf_apimgr.h"
//#include "hxdw_utils.h"
//#include <stdio.h>
//#include <mmsystem.h>   //PlaySound()
//#include "MinHook.h"

// extern in the .h file.
PrfData* Prf2 = nullptr;

const std::vector<std::pair<HKEY,std::string>>&
PrfRegGetPredefinedRootKeyDefn()
{
	static const std::vector<std::pair<HKEY,std::string> > aPRKeyNames ={
		{ HKEY_CLASSES_ROOT,  "HKEY_CLASSES_ROOT",},
		{ HKEY_CURRENT_USER,  "HKEY_CURRENT_USER",},
		{ HKEY_LOCAL_MACHINE, "HKEY_LOCAL_MACHINE",},
		{ HKEY_USERS,         "HKEY_USERS",},
		{ HKEY_CURRENT_CONFIG, "HKEY_CURRENT_CONFIG",},
		{ HKEY_PERFORMANCE_TEXT, "HKEY_PERFORMANCE_TEXT",},
		{ HKEY_PERFORMANCE_NLSTEXT, "HKEY_PERFORMANCE_NLSTEXT",},
		{ HKEY_CURRENT_USER_LOCAL_SETTINGS, "HKEY_CURRENT_USER_LOCAL_SETTINGS",},
		{ HKEY_PERFORMANCE_DATA, "HKEY_PERFORMANCE_DATA",},
	};
	return aPRKeyNames;
}
bool PrfRegIsPredefinedRootKey( HKEY hKeyInp )
{
	const auto& aPRKeys = PrfRegGetPredefinedRootKeyDefn();
	using el_t = decltype( *aPRKeys.begin() );
	auto a = std::find_if( aPRKeys.begin(), aPRKeys.end(), [&]( const el_t& vElem )->bool{
			return vElem.first == hKeyInp;
		});
	return a != aPRKeys.end();
}
std::string PrfRegRootKeyToStr( HKEY hKeyInp, const char* flags2 )
{
	bool bOnlyRootKeys = !!std::strchr( flags2, 'r');

	if( !bOnlyRootKeys && !PrfRegIsPredefinedRootKey( hKeyInp ) ){
		return hxdw_StrPrintf("[hKey:%a]", { (int64_t)hKeyInp,});
	}
	const auto& aPRKeyNames = PrfRegGetPredefinedRootKeyDefn();
	for( auto a = aPRKeyNames.cbegin(); a != aPRKeyNames.cend(); ++a ){
		if( a->first == hKeyInp ){
			return a->second;
		}
	}
	if( bOnlyRootKeys )
		return "";
	return hxdw_StrPrintf("<unknown_3gYGTo:%a>", { (int64_t)hKeyInp,});
}
const std::vector<std::pair<DWORD,std::string>>&
PrfRegGetDataTypeArray()
{
	static const std::vector<std::pair<DWORD,std::string> > aDtNames2 ={
		{ REG_BINARY,               "REG_BINARY",},
		{ REG_DWORD,                "REG_DWORD",},
		{ REG_DWORD_LITTLE_ENDIAN,  "REG_DWORD_LITTLE_ENDIAN",},
		{ REG_DWORD_BIG_ENDIAN,     "REG_DWORD_BIG_ENDIAN",},
		{ REG_EXPAND_SZ,            "REG_EXPAND_SZ",},
		{ REG_LINK,                 "REG_LINK",},
		{ REG_MULTI_SZ,             "REG_MULTI_SZ",},
		{ REG_NONE,                 "REG_NONE",},
		{ REG_RESOURCE_LIST,        "REG_RESOURCE_LIST",},
		{ REG_SZ,                   "REG_SZ",},
	};
	return aDtNames2;
}
std::string PrfRegDataTypeToStr2( DWORD dwType2, const char* flags2 )
{
	const bool bREmptyIfNone = !!std::strchr( flags2, 'e');
	const auto& aDtNames2 = PrfRegGetDataTypeArray();
	for( auto a = aDtNames2.cbegin(); a != aDtNames2.cend(); ++a ){
		if( a->first == dwType2 ){
			return a->second;
		}
	}
	return ( bREmptyIfNone ? "" : "<unknown_9TwClY>");
}
/// Gets reg type as value, eg. REG_SZ.
/// \sa PrfRegDataTypeToStr2()
HxdwQuad2<bool,DWORD,int,int>
PrfRegStrToDataType2( const char* szDataTyoe, const char* flags2_ )
{
	if( szDataTyoe && *szDataTyoe ){
		const auto& aDtNames2 = PrfRegGetDataTypeArray();
		for( auto a = aDtNames2.cbegin(); a != aDtNames2.cend(); ++a ){
			if( a->second == szDataTyoe ){
				return { 1L, a->first, 0, 0,};
			}
		}
	}
	return { 0L, 0, 0, 0,};
}

std::string PrfRegDataToStr2( DWORD dwType, const uint8_t* lpData, DWORD cbData )
{
	std::string outp;

	if( dwType == REG_DWORD ){
		if( sizeof(DWORD) <= cbData ){
			outp = std::to_string( *((DWORD*)lpData) );
		}else{
			outp = "error_NlTqYi";
		}
	}else if( dwType == REG_QWORD ){
		if( sizeof(uint64_t) <= cbData ){
			outp = std::to_string( *((uint64_t*)lpData) );
		}else{
			outp = "error_0HuOjn";
		}
	//}else if( dwType == REG_DWORD_LITTLE_ENDIAN ){
		//REG_DWORD_LITTLE_ENDIAN
		//REG_DWORD_BIG_ENDIAN
		//REG_QWORD_LITTLE_ENDIAN
		;
	}else if( dwType == REG_SZ || dwType == REG_EXPAND_SZ || dwType == REG_MULTI_SZ ){
		std::string sr2;
		sr2.assign( (char*)lpData, cbData );
		outp = hxdw_TextSBHEncode( sr2.c_str(), sr2.size(), "");
	}else{
		// dwType == REG_BINARY, and all others.
		outp = hxdw_HexEncode2( lpData, cbData, "");
	}
	return outp;
}

/**
	Converts custom, possibly encoded string back into data compatible with
	Winapi Reg functions.

	Winapi note: \verbatim
		If the buffer specified by lpData parameter is not large enough to
		hold the data, the function returns ERROR_MORE_DATA and stores the
		required buffer size in the variable pointed to by lpcbData.
	\endverbatim
*/
HxdwQuad2<bool,LONG,int,int>
PrfRegStrToData2( const char* inp, DWORD dwType, uint8_t* lpData, DWORD* lpIODataSize )
{
	assert( lpData );
	assert( lpIODataSize );
	const DWORD dwBufSize = *lpIODataSize; char* dmy0;
	if( dwType == REG_DWORD ){
		DWORD val2 = (DWORD) std::strtoull( inp, &dmy0, 10 );
		*lpIODataSize = sizeof(DWORD);
		if( dwBufSize < sizeof(DWORD) ){
			return { 0L, ERROR_MORE_DATA, 0, 0,};
		}
		*((DWORD*)lpData) = val2;
	}else if( dwType == REG_QWORD ){
		uint64_t val2 = (uint64_t) std::strtoull( inp, &dmy0, 10 );
		*lpIODataSize = sizeof(uint64_t);
		if( dwBufSize < sizeof(uint64_t) ){
			return { 0L, ERROR_MORE_DATA, 0, 0,};
		}
		*((uint64_t*)lpData) = val2;
	}else if( dwType == REG_SZ || dwType == REG_EXPAND_SZ || dwType == REG_MULTI_SZ ){
		std::string data2;
		data2 = hxdw_TextSBHDecode( inp, size_t(-1), "");
		size_t uRqSize = data2.size();
		if( dwType == REG_MULTI_SZ ){
			if( !hxdw_EndsWith( data2.c_str(), data2.size(), "\0\0", 2, "") ){
				if( hxdw_EndsWith( data2.c_str(), data2.size(), "\0", 1, "") ){
					data2.append( "\0", 1 );
				}else{
					data2.append( "\0\0", 2 );
				}
				uRqSize = data2.size();
			}
		}else{
			uRqSize += !hxdw_EndsWith( data2.c_str(), data2.size(), "\0", 1, "");
		}
		*lpIODataSize = uRqSize;
		if( dwBufSize < uRqSize ){
			return { 0L, ERROR_MORE_DATA, 0, 0,};
		}
		memcpy( lpData, data2.c_str(), uRqSize );
	}else{
		// dwType == REG_BINARY, and all others.
		std::vector<uint8_t> data5;
		data5 = +hxdw_HexDecode2( inp, size_t(-1), "");
		*lpIODataSize = data5.size();
		if( dwBufSize < data5.size() ){
			return { 0L, ERROR_MORE_DATA, 0, 0,};
		}
		memcpy( lpData, data5.data(), data5.size() );
	}
	return { 1L, ERROR_SUCCESS, 0, 0,};
}
PrfData::PrfData()
	: ini2( *new hxdw_IniData2 )
	, rt2( *new PrfRegHKTracker )
	, am2( *new PrfApiDtrMgr )
{
}
PrfData::~PrfData()
{
	{
		hxdw_IniData2* ini2_ = &ini2;
		assert( ini2_ );
		delete ini2_;
	}{
		PrfRegHKTracker* rt2_ = &rt2;
		assert( rt2_ );
		delete rt2_;
	}{
		PrfApiDtrMgr* am2_ = &am2;
		assert( am2_ );
		delete am2_;
	}
}
PrfRegHKTracker::PrfRegHKTracker()
	: ini3( *new hxdw_IniData2 )
{
}
PrfRegHKTracker::~PrfRegHKTracker()
{
	{
		hxdw_IniData2* ini3_ = &ini3;
		assert( ini3_ );
		delete ini3_;
	}
}

bool PrfRegHKTracker::setDatabaseINIFile( const char* szIniFName )
{
	mIniFName = szIniFName;
	hxdw_IniData2 ini4 = hxdw_ParseINIFile( szIniFName );
	ini3 = ini4;
	return !ini3.isINIEmpty();
}
bool PrfRegHKTracker::addKeyDetour2( const char* szAbsKPath )
{
	std::string srAbsKPath3 = hxdw_FixPathSeparators( szAbsKPath, "");
	mDPaths2.push_back( srAbsKPath3 );
	return 1L;
}
HxdwQuad2<bool,bool>
PrfRegHKTracker::testPathForDetour( HKEY hKeyParent, const char* szSubKey2,
		std::string* err_, std::string* srFullPathOu )const
{
	std::string sink2, &err2 = ( err_ ? *err_ : sink2 );
	if( !hKeyParent ){
		err2 = hxdw_StrPrintf("Null reg key in hKeyParent parameter. P:[%a] [D3Q7JQ]", {
				( szSubKey2 ? szSubKey2 : "<null2>" ),});
		return { 0L, 0L, 0, 0,};
	}
	if( !szSubKey2 ){
		err2 = hxdw_StrPrintf("Null 'szSubKey2' parameter from user. K:[%a] [BfGQPg]", {
				PrfRegRootKeyToStr( hKeyParent, ""),
				});
		return { 0L, 0L, 0, 0,};
	}
	std::string srPath2;
	if( PrfRegIsPredefinedRootKey( hKeyParent ) ){
		std::string sr2 = PrfRegRootKeyToStr( hKeyParent, "r");
		assert( !sr2.empty() );
		srPath2 = sr2;
	}else{
		auto ir2 = std::find_if( mATracked.begin(), mATracked.end(),
			[&]( const STrckd& td2 )->bool{
				return td2.hKeyOpened2 == hKeyParent;
			});
		if( ir2 != mATracked.end() ){
			srPath2 = ir2->srKeyPath2;
		}else{
			err2 = hxdw_StrPrintf("Untrackable reg key in hKeyParent parameter K:[%a] P:[%a] [odpWdW]", {
					PrfRegRootKeyToStr( hKeyParent, ""),
					( szSubKey2 ? szSubKey2 : "<null2>" ),});
			return { 0L, 0L, 0, 0,};
		}
	}
	std::string srPathNeedle2 = hxdw_StrPrintf("%s%s%s", {
			srPath2,
			std::string( szSubKey2 ? "\\"      : ""),
			std::string( szSubKey2 ? szSubKey2 : ""),});
	{
		const bool bAbs2 = hxdw_IsAbsolutePath( srPathNeedle2 );
		assert( !bAbs2 );
	}
	bool bForDetour2 = 0L;
	for( auto ir2 = mDPaths2.begin(); ir2 != mDPaths2.end(); ++ir2 ){
		if( hxdw_TestPathStartsWith( srPathNeedle2, ir2->c_str(), "e") ){
			bForDetour2 = 1L;
			break;
		}
	}
	if( srFullPathOu ){
		*srFullPathOu = srPathNeedle2;
	}
	return { bForDetour2, 1L, 0, 0,};
}
/**
	Adds key for tracking and|or derouring.
	// \ param flags3 - flags. eg. PRF_ETrkOnCreateKey,
*/
bool PrfRegHKTracker::
addKeyForTracking2( HKEY hKeyParent, const char* szSubKey2, HKEY hKeyOpened,
		size_t flags3, std::string* err_, std::string* srFullPathOu3 )
{
	assert( hKeyParent );
	assert( hKeyOpened );
	std::string sink2, &err2 = ( err_ ? *err_ : sink2 );
	std::string srKeyPath3;
	auto res3 = testPathForDetour( hKeyParent, szSubKey2, &err2, &srKeyPath3 );
	if( !+res3 ){
		assert( !*res3 );
		return 0L;
	}
	if( srFullPathOu3 ){
		*srFullPathOu3 = srKeyPath3;
	}
	{
		STrckd st2;
		st2.hKeyOpened2 = hKeyOpened;
		st2.hKeyParent2 = hKeyParent;
		st2.srKeyPath2  = srKeyPath3;
		st2.bDetoured3  = 0L;//bForDetour3;
		mATracked.push_back( st2 );
	}
	//if( bForDetour3 && (flags3 & PRF_ETrkOnCreateKey) ){
	//	;
	//}
	return 1L;
}
HKEY PrfRegHKTracker::addOwnKeyForTracking2( const char* szKPath2 )
{
	STrckd st2;
	st2.hKeyOpened2 = (HKEY) ++mLastOwnKeyVal;
	st2.hKeyParent2 = 0;
	st2.srKeyPath2  = szKPath2;
	st2.bDetoured3  = 1L;
	mATracked.push_back( st2 );
	return st2.hKeyOpened2;
}
HxdwQuad2<bool,LONG,int,int>
PrfRegHKTracker::createRegKey2( const PrfCrKey2& inp )
{
	const int uCreateCount2 = (1 + atoi( ini3.getValue( inp.srKPath3.c_str(),"uCreateCount2","0").c_str() ));
	ini3.setValue( inp.srKPath3.c_str(), "uCreateCount2", std::to_string(uCreateCount2).c_str() );

	HKEY hOwnKey2 = addOwnKeyForTracking2( inp.srKPath3.c_str() );
	assert( hOwnKey2 );
	if( inp.lpdwDisposition2 ){
		*inp.lpdwDisposition2 = ( uCreateCount2 <= 1 ? REG_CREATED_NEW_KEY : REG_OPENED_EXISTING_KEY );
	}
	if( inp.phKeyOut2 ){
		*inp.phKeyOut2 = hOwnKey2;
	}
	return { 1L, ERROR_SUCCESS, 0, 0,};
}
HxdwQuad2<bool,LONG,int,int>
PrfRegHKTracker::openRegKey2( const PrfOpenKey2& inp )
{
	bool bSecExists = 0L;
	ini3.eachSection( [&]( const hxdw_IniSection& sec2 )->bool{
		if( !hxdw_StrCmpOpt3( sec2.first.c_str(), inp.srKPath3.c_str(), size_t(-1), "i")){
			bSecExists = 1L;
			return 0L;
		}
		return 1L;
	});
	if( !bSecExists ){
		SetLastError( ERROR_FILE_NOT_FOUND );
		return { 0L, ERROR_FILE_NOT_FOUND, 0, 0,};
	}
	HKEY hOwnKey2 = addOwnKeyForTracking2( inp.srKPath3.c_str() );
	assert( hOwnKey2 );
	if( inp.phKeyOut2 ){
		*inp.phKeyOut2 = hOwnKey2;
	}
	return { 1L, ERROR_SUCCESS, 0, 0,};
}

std::vector<PrfRegHKTracker::STrckd>::iterator
PrfRegHKTracker::findKey2( HKEY hKey )
{
	auto ir2 = std::find_if( mATracked.begin(), mATracked.end(),
		[&]( const STrckd& td2 )->bool{
			return td2.hKeyOpened2 == hKey;
		});
	return ir2;
}
HxdwQuad2<bool,bool,std::string,int>
PrfRegHKTracker::isKeyTracked2( HKEY hKey )const
{
	auto ir2 = const_cast<PrfRegHKTracker*>(this)->findKey2( hKey );
	if( ir2 != mATracked.end() ){
		return { 1L, ir2->bDetoured3, ir2->srKeyPath2, 0,};
	}
	return { 0L, 0L, "", 0,};
}
HxdwQuad2<bool,bool,std::string>
PrfRegHKTracker::closeRegKeyIf2( HKEY hKey, const char* flags2_ )
{
	auto ir2 = findKey2( hKey );
	if( ir2 != mATracked.end() ){
		//bool bSaveFile = !!std::strchr( flags2_, 's');
		//if( bSaveFile ){
		//	bSaveFile = 1;
		//}
		if( Prf2->eSaveINIStrategy & PRF_ESIS_OnRegApiClose ){
			saveINIFile();
		}
		const STrckd cpy2 = *ir2;
		mATracked.erase( ir2 );
		return { 1L, cpy2.bDetoured3, cpy2.srKeyPath2, 0,};
	}
	return { 0L, 0L, "", 0,};
}
/// Tests if the input c-string is in a key varname format.
/// Returns the same value as getKeyVarnameIndexIfAny().
HxdwQuad2<bool,size_t,int,int>
PrfRegHKTracker::isKeyVarnameByToken( const char* keyname2 )const
{
	if( hxdw_BeginsWith( keyname2, size_t(-1), mVnToken2.c_str(), size_t(-1), "") ){
		if( hxdw_EndsWith( keyname2, size_t(-1), ".name2", size_t(-1), "") ){
			auto res2 = getKeyVarnameIndexIfAny( keyname2 );
			assert( *res2 );
			return { 1L, +res2, 0, 0,};
		}
	}
	return { 0L, 0, 0, 0,};
}
/**
	Retrieves key varname numeric_index string.

	Returns:
		{ success, numeric_index, 0, 0, }

		numeric_value: Part afer the "var2." in the key string.
		               Eg. for key "var2.3.name2" retrieved value is 3.
*/
HxdwQuad2<bool,size_t,int,int>
PrfRegHKTracker::getKeyVarnameIndexIfAny( const char* keyname2 )const
{
	if( !hxdw_StrCmpOpt3( mVnToken2.c_str(), keyname2, mVnToken2.size(), "") ){
		const char* szDigits = &keyname2[ mVnToken2.size() + 1 ];
		size_t nDigitsVal = (size_t) hxdw_StrToDbl( szDigits, 0 );
		return { 1L, nDigitsVal, 0, 0,};
	}
	return { 0L, 0, 0, 0,};
}
HxdwQuad2<bool,LONG,int,int>
PrfRegHKTracker::setRegValue2( const PrfSetVal2& inp )
{
	auto ir2 = findKey2( inp.hKey );
	assert( ir2 != mATracked.end() );
	const uint64_t uSetvalCount2 = uint64_t(1.0 + hxdw_StrToDbl( ini3.getValue( ir2->srKeyPath2.c_str(),"uSetvalCount2","0").c_str(), 0 ));
	ini3.setValue( ir2->srKeyPath2.c_str(), "uSetvalCount2", std::to_string(uSetvalCount2).c_str() );
	size_t uVarNo2 = 0; bool bByName = 0L;
	if( inp.bValCanBePath ){
		;//WIP.
		;
	}
	const std::string srVarName = ( inp.szValueName && *inp.szValueName ? inp.szValueName : "default_value_3Tg3vN");
	ini3.eachVariable( { ir2->srKeyPath2.c_str(),},
		[&]( const char* secname, const char* kname, const char* value2 )->bool{
			auto res2 = isKeyVarnameByToken( kname );
			if( *res2 ){
				uVarNo2 = std::max<size_t>( uVarNo2, +res2 );
				if( !hxdw_StrCmpOpt3( value2, srVarName.c_str(), size_t(-1), "i") ){
					uVarNo2 = +res2;
					bByName = 1L;
					return 0L;
				}
			}
			return 1L;
		});
	if( !bByName )
		uVarNo2 += 1;
	std::string srVarNameName2  = hxdw_StrPrintf("var2.%a.name2", { (int64_t)(uVarNo2),});
	std::string srVarNameValue2 = hxdw_StrPrintf("var2.%a.val2", { (int64_t)(uVarNo2),});
	std::string srVarNameType2  = hxdw_StrPrintf("var2.%a.ty2", { (int64_t)(uVarNo2),});

	std::string srVarVal;
	srVarVal = PrfRegDataToStr2( inp.dwType, inp.lpData, inp.cbData );

	ini3.setValue( ir2->srKeyPath2.c_str(), srVarNameName2.c_str(), srVarName.c_str() );
	ini3.setValue( ir2->srKeyPath2.c_str(), srVarNameType2.c_str(), PrfRegDataTypeToStr2(inp.dwType,"e").c_str() );
	ini3.setValue( ir2->srKeyPath2.c_str(), srVarNameValue2.c_str(), srVarVal.c_str() );
	return { 1L, ERROR_SUCCESS, 0, 0,};
}

// If lpValueName is NULL or an empty string, "", the function retrieves the type and data for the key's unnamed or default value, if any.
// If lpValueName specifies a value that is not in the registry, the function returns ERROR_FILE_NOT_FOUND.
HxdwQuad2<bool,LONG,int,int>
PrfRegHKTracker::getRegValue2( const PrfGetVal2& inp )
{
	if( inp.lpData && !inp.lpcbData ){
		return { 0L, ERROR_INVALID_PARAMETER, 0, 0,};
	}
	const std::string srVarname = ( inp.szValueName && *inp.szValueName ? inp.szValueName : "default_value_3Tg3vN");
	auto ir2 = findKey2( inp.hKey );
	assert( ir2 != mATracked.end() );

	bool bVarnameFound = 0L; size_t uVarNo3 = size_t(-1);
	ini3.eachVariable( { ir2->srKeyPath2.c_str(),},
		[&]( const char* secname, const char* kname, const char* value2 )->bool{
			auto res2 = isKeyVarnameByToken( kname );
			if( *res2 ){
				if( !hxdw_StrCmpOpt3( value2, srVarname.c_str(), size_t(-1), "i") ){
					uVarNo3 = +res2;
					bVarnameFound = 1L;
					return 0L;   // 0: end enumeration.
				}
			}
			return 1L;
		});
	if( !bVarnameFound ){
		return { 0L, ERROR_FILE_NOT_FOUND, 0, 0,};
	}
	assert( uVarNo3 != size_t(-1) );
	std::string srVarNameValue3, srVarNameType3, srRegValRaw, srRegValTy;
	srVarNameValue3 = hxdw_StrPrintf("var2.%a.val2", { (int64_t)(uVarNo3),});
	srVarNameType3  = hxdw_StrPrintf("var2.%a.ty2", { (int64_t)(uVarNo3),});
	srRegValRaw = ini3.getValue( ir2->srKeyPath2.c_str(), srVarNameValue3.c_str(), "");
	srRegValTy  = ini3.getValue( ir2->srKeyPath2.c_str(), srVarNameType3.c_str(), "");
	auto res2 = PrfRegStrToDataType2( srRegValTy.c_str(), "" );
	if( !*res2 ){
		return { 0L, ERROR_INVALID_DATA, 0, 0,};
	}
	if( inp.lpType ){
		*inp.lpType = +res2;
	}
	if( inp.lpData ){
		assert( inp.lpcbData );
		auto res3 = PrfRegStrToData2( srRegValRaw.c_str(), +res2, inp.lpData, inp.lpcbData );
		return { *res3, +res3, 0, 0,};
	}else{
		if( inp.lpcbData ){
			uint8_t sink3[1]="";
			DWORD uNum2 = sizeof(sink3);
			auto res4 = PrfRegStrToData2( srRegValRaw.c_str(), +res2, sink3, &uNum2 );
			*inp.lpcbData = uNum2;
			return { *res4, +res4, 0, 0,};
		}
		return { 1L, ERROR_SUCCESS, 0, 0,};
	}
}
bool PrfRegHKTracker::saveINIFile()
{
	if( !mIniFName.empty() ){
		//ini3.alterSection2("add_4fr5xm", "s_test2" );
		//ini3.alterSection2("clear_4fr5xm", "s_test2" );
		//ini3.alterSection2("remove_4fr5xm", "s_test2" );

		std::string srIni2 = ini3.getAsString();
		bool rs2 = hxdw_PutFileContents( mIniFName.c_str(), srIni2.c_str(), srIni2.size(), "");
		if( !rs2 ){
			hxdw_StdPrint3(
				"PRF: ERROR: Failed writing INI file (%a bytes) [rW4uFy]\n"
				"     FIle: [%a]\n", {
					(int64_t)srIni2.size(),
					mIniFName,});
			return 0L;
		}
		return 1L;
	}
	return 0L;
}
template<class TCh>
bool PrfRegValidateRegEnumKeyExParams( const PrfRegEnumKeyExParams<TCh>& inp )
{
	if( !inp.lpName || !inp.lpcbName ){
		return 0;// ERROR_INVALID_PARAMETER
	}
	if( !inp.lpClass && inp.lpcbClass ){
		return 0;//ERROR_INVALID_PARAMETER
	}
	return 1;
}
// Explicit instantiations
template
bool PrfRegValidateRegEnumKeyExParams<char>( const PrfRegEnumKeyExParams<char>& inp );
template
bool PrfRegValidateRegEnumKeyExParams<wchar_t>( const PrfRegEnumKeyExParams<wchar_t>& inp );

/// Called in response to RegEnumKeyEx API calls.
HxdwQuad2<bool,LONG>
PrfRegHKTracker::getRegKeyEnumInfoAtIndex2( const PrfEnumKey2& inp )
{
	if( !inp.lpName || !inp.lpcbName ){
		return { 0L, ERROR_INVALID_PARAMETER, 0, 0,};
	}
	auto ir2 = findKey2( inp.hKey );
	assert( ir2 != mATracked.end() );

	HxdwQuad2<size_t,std::string> srVarnameRes = { size_t(-1), "", 0,0,};
	{
		size_t uEnumIndexAt2 = 0;
		ini3.eachVariable( { ir2->srKeyPath2.c_str(),},
			[&]( const char* secname_, const char* kname, const char* value2 )->bool{
				auto res2 = isKeyVarnameByToken( kname );
				if( *res2 ){
					if( !!hxdw_StrCmpOpt3("default_value_3Tg3vN", value2, size_t(-1), "")){
						if( inp.dwIndex == uEnumIndexAt2 ){
							assert( +res2 != size_t(-1) );
							srVarnameRes = { +res2, value2, 0,0,};
							return 0L;  // 0: end enumeration.
						}
						uEnumIndexAt2 += 1;
					}
				}
				return 1L;
			});
	}
	if( *srVarnameRes != size_t(-1) ){
		const size_t uInpBufSize = *inp.lpcbName;
		*inp.lpcbName = srVarnameRes.second.size();
		size_t uNumCpy = ( srVarnameRes.second.size() + 1 );
		if( uInpBufSize < uNumCpy ){
			return { 0L, ERROR_MORE_DATA, 0, 0,};
		}
		memcpy( inp.lpName, srVarnameRes.second.c_str(), uNumCpy );
		return { 1L, ERROR_SUCCESS, 0, 0,};
	}
	return { 0L, ERROR_NO_MORE_ITEMS, 0, 0,};
}
HxdwQuad2<bool,LONG,int,int>
PrfRegHKTracker::deleteRegKey2( const PrfDelKey2& inp )
{
	if( !inp.lpSubKey || !*inp.lpSubKey ){
		return { 0L, ERROR_INVALID_PARAMETER, 0, 0,};
	}
	auto ir2 = findKey2( inp.hKey );
	assert( ir2 != mATracked.end() );

	std::string srKeyPath3;
	bool rs2 = *testPathForDetour( inp.hKey, inp.lpSubKey, nullptr, &srKeyPath3 );
	assert( rs2 );

	auto res2 = ini3.querySection2("count_keys_4fr5xm", srKeyPath3.c_str() );
	if( *res2 && !+res2 ){
		if( ini3.alterSection2("remove_4fr5xm", srKeyPath3.c_str() ) ){
			return { 1L, ERROR_SUCCESS, 0, 0,};
		}
	}
	//assert(!002);
	return { 0L, ERROR_INVALID_PARAMETER, 0, 0,};
}
