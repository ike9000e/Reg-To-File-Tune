#include "prf_dll_main.h"


int dll_dummy_MUmB8YrA7()
{
	return 42;
}

bool PrfDllMainOnProcessAttach()
{
	assert( !Prf2 );
	Prf2 = new PrfData;
	Prf2->srSelfDllPathName = hxdw_GetModuleFileNameFromAddr( DllMain );
	Prf2->srSelfDllDirName  = hxdw_SplitPath( Prf2->srSelfDllPathName ).first;
	Prf2->srSelfDllBaseName = hxdw_SplitPath( Prf2->srSelfDllPathName ).second;
	Prf2->srSelfExePathName = hxdw_GetCurrentExecutableFilePath();
	Prf2->srSelfExeBaseName = hxdw_SplitPath( Prf2->srSelfExePathName ).second;

	Prf2->srIniPathName     = hxdw_StrPrintf("%s\\%s.ini", { Prf2->srSelfDllDirName,
		hxdw_TrimStr( hxdw_SplitExt( Prf2->srSelfDllBaseName ).first, "0123456789_","R",-1),});


	Prf2->ini2 = hxdw_ParseINIFile( Prf2->srIniPathName.c_str() );
	if( Prf2->ini2.isINIEmpty() ){
		std::string msg3 = ( !hxdw_FileExists( Prf2->srIniPathName.c_str() ) ? "File not found." : "No data." );
		MessageBox( 0, hxdw_StrPrintf(
				"ERROR: Parsing INI configuration failed.\n\n"
				"File:\n[%a]\n\n%s\n",{
				Prf2->srIniPathName, msg3,}).c_str(),
			Prf2->srSelfDllBaseName.c_str(), MB_ICONERROR );
		return 0L;
	}
	{
		Prf2->eConsoleIOFixMode = size_t( atoi( Prf2->ini2.getValue("s_main","eConsoleIOFixMode","0").c_str()));
		if( Prf2->eConsoleIOFixMode == 1 ){
			AllocConsole();
		}else if( Prf2->eConsoleIOFixMode == 2 ){
			hxdw_AttachConsoleEnvIf2("");
		}else if( hxdw_Any<size_t>( Prf2->eConsoleIOFixMode, {3,4,})){
			uint32_t uCmdPid2 = 0;
			( Prf2->eConsoleIOFixMode == 3 ? hxdw_FindParentCMDWindow( 0, &uCmdPid2, "") :
				hxdw_FindChildCMDWindow( 0, &uCmdPid2, "") );
			if( uCmdPid2 )
				AttachConsole( uCmdPid2 );
		}
	}
	hxdw_StdPrint3("PRF: <<%a>> ... starting...\n", { Prf2->srAppName,});
	std::string msg2 = hxdw_StrPrintf(
			"DLL process attach. PID:%a; [%a] [%a]", {
				(uint32_t)GetCurrentProcessId(),
				Prf2->srSelfExeBaseName.c_str(),
				Prf2->srSelfDllBaseName.c_str(),});
	hxdw_StdPrint3("PRF: %a\n", { msg2,});
	if( atoi( Prf2->ini2.getValue("s_main","bShowReadyMsg","0").c_str() ) ){
		MessageBox( 0, hxdw_StrPrintf("Ready.\n\n%a\n", { msg2,}).c_str(),
			Prf2->srSelfDllBaseName.c_str(), MB_ICONINFORMATION );
	}
	{
	/*	HRESULT rs2 = TaskDialog(
			0,
			//0,//hInst,
			GetModuleHandle(0),
			//(HINSTANCE)hxdw_GetModuleBaseAddress( 0, 0 ),
			L"abc",
			nullptr,
			nullptr,
			0,
			TD_INFORMATION_ICON,
			0
			);
		if( rs2 != S_OK ){
			MessageBox( 0, "ERROR_2","PRF", 0 );
		}//*/
	}
	Prf2->bHandleRundll32 = !!atoi( Prf2->ini2.getValue("s_main","bHandleRundll32","0").c_str() );
	if( Prf2->bHandleRundll32 && !hxdw_StrCmpOpt3("rundll32.exe", Prf2->srSelfExeBaseName.c_str(), -1, "i" ) ){
		return 1L;
	}
	{
		Prf2->srDbsIniPathName = Prf2->ini2.getValue("s_main","anRegINIFilePath","").c_str();
		if( !Prf2->srDbsIniPathName.empty() ){
			if( !hxdw_IsWithPathPart( Prf2->srDbsIniPathName.c_str() ) ){
			}
		}
		if( Prf2->srDbsIniPathName.empty() ){
			Prf2->srDbsIniPathName = hxdw_StrPrintf("%s\\%s.reg.ini", { Prf2->srSelfDllDirName,
				hxdw_TrimStr( hxdw_SplitExt( Prf2->srSelfDllBaseName ).first, "0123456789_","R",-1),});
		}
		Prf2->rt2.setDatabaseINIFile( Prf2->srDbsIniPathName.c_str() );
	}{
		PrfRegDetoursInit();
		size_t uCntKDtrs = 0;
		Prf2->ini2.eachVariable( {"s_main",}, [&]( const char*, const char* kname, const char* value2 ){
				if( *value2 && hxdw_BeginsWith( kname, size_t(-1), "anDetourPath", size_t(-1), "") ){
					Prf2->rt2.addKeyDetour2( value2 );
					uCntKDtrs += 1;
				}
				return 1L;
		});
		if( !uCntKDtrs ){
			MessageBox( 0, ( hxdw_StrPrintf(
					"ERROR: No registry config paths found.\n\n"
					"(This refers to the velue named 'anDetourPath' under the "
					"'[s_main]' section in the INI configuration file.)\n", {}).c_str()),
				Prf2->srSelfDllBaseName.c_str(), MB_ICONERROR );
			return 0L;
		}
	}
	{
		Prf2->bShowRegOpeners     = !!atoi( Prf2->ini2.getValue("s_main","bShowRegOpeners","0").c_str() );
		Prf2->bShowRegSetters     = !!atoi( Prf2->ini2.getValue("s_main","bShowRegSetters","0").c_str() );
		Prf2->bShowRegGetters     = !!atoi( Prf2->ini2.getValue("s_main","bShowRegGetters","0").c_str() );
		Prf2->bShowRegClose       = !!atoi( Prf2->ini2.getValue("s_main","bShowRegClose","0").c_str() );
		Prf2->bShowRegEnumerators = !!atoi( Prf2->ini2.getValue("s_main","bShowRegEnumerators","0").c_str() );
		Prf2->bShowRegDeleters    = !!atoi( Prf2->ini2.getValue("s_main","bShowRegDeleters","0").c_str() );
	}
/*	{
		char szInp2[] = "[\r\n]--\0--";
		std::string srEcdd, srDcdd, srDcddH2, sr2;
		sr2.assign( szInp2, sizeof(szInp2)-1 );
		srEcdd   = hxdw_TextSBHEncode( sr2.c_str(), sr2.size(), "" );
		srDcdd   = hxdw_TextSBHDecode( srEcdd.c_str(), -1, "" );
		srDcddH2 = hxdw_HexEncode2( srDcdd.c_str(), srDcdd.size(), "c");
		MessageBox( 0, hxdw_StrPrintf(
			"Encoded: [%a]\n""Decoded: [%a]\n""Decoded-h: [%a]\n", {
				srEcdd.c_str(),
				srDcdd.c_str(),
				srDcddH2.c_str(),
			}).c_str(), "PRF:", 0);
	}//*/
/*	{
		wchar_t inp2[] = L"AB\0-C";
		std::string sr2 = hxdw_StrWcsToUtf8a( inp2, sizeof(inp2)/sizeof(inp2[0]) );
		MessageBox( 0, hxdw_StrPrintf(
			"As c-string: [%a] len:%a\n""Hex: [%a]\n", {
				sr2.c_str(),
				(int64_t)sr2.size(),
				hxdw_HexEncode2( sr2.c_str(), sr2.size(), "c").c_str(),
			}).c_str(), "PRF:", 0);
	}//*/
	{
		//LONG rs2 = RegSetValueExA( 0, "a", 0, REG_SZ, (uint8_t*)"abc", 3 );
		//hxdw_StdPrint3("PRF: rs2:[%a]\n", { (int64_t)rs2,});
		//MessageBox( 0,"","",0);//*/

		//bool bBgns = hxdw_BeginsWith( "abc", -1, "abC", -1, "i");
		//hxdw_StdPrint3("PRF: bBgns:[%a]\n", { (int64_t)bBgns,});
		//MessageBox( 0,"","PRF: test...",0);
	}{
		/*hxdw_StdPrint3("PRF: paths:\n[%a]\n[%a]\n[%a]\n[%a]\n[%a]\n", {
				hxdw_FixPathSeparators("c:\\a\\b", ""),
				hxdw_FixPathSeparators(".\\a\\",""),
				hxdw_FixPathSeparators("./abc/\\/\\def",""),
				hxdw_FixPathSeparators("./abc/\\/\\def","s"),
				hxdw_FixPathSeparators("\\\\","s"),
			});
		MessageBox( 0,"","PRF: test...",0);//*/
	}
	return 1L;
}
BOOL WINAPI DllMain( HINSTANCE, DWORD dwReason, LPVOID )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:{
			PrfDllMainOnProcessAttach();
		}
		break;
	case DLL_PROCESS_DETACH:{
			//return PrfDetoursDeinit();
		}
		break;
	}
	return 1L;
}

/*
	Run this function by running the DLL file with the following rundll32
	command:
		rundll32.exe project_dll_64.dll,RDEntryPoint
*/
void CALLBACK
RDEntryPoint( HWND hwnd, HINSTANCE hInst, const char* lpszCmdLine, int nCmdShow )
{
	//InitCommonControls();

	hxdw_StdPrint3("PRF: RDEntryPoint(), hinst:%a\n", {
		(uint32_t)(size_t)hInst,
		});

/*	//HANDLE hDll2 = LoadLibraryEx("comctl32.dll", 0,
	//		0x00000800|//LOAD_LIBRARY_SEARCH_SYSTEM32
	//		0x00000001|
	//		0);
	//HANDLE hDll2 = (HANDLE)hxdw_GetModuleBaseAddress( 0, "comctl32.dll" );
	HANDLE hDll2 = LoadLibrary("comctl32.dll");
	assert( hDll2 );
	//void* fncTaskDialog = (void*)GetProcAddress( (HMODULE)hDll2, "TaskDialog" );
	void* fncTaskDialog = (void*)GetProcAddress( (HMODULE)hDll2, "_TaskDialog@32" );
	assert( fncTaskDialog );
	using TaskDialog_ty = HRESULT(__stdcall*)(
		  HWND                           hwndOwner,
		  HINSTANCE                      hInstance,
		  PCWSTR                         pszWindowTitle,
		  PCWSTR                         pszMainInstruction,
		  PCWSTR                         pszContent,
		  //TASKDIALOG_COMMON_BUTTON_FLAGS dwCommonButtons,
		  DWORD dwCommonButtons,
		  PCWSTR                         pszIcon,
		  int                            *pnButton
		);
	((TaskDialog_ty) fncTaskDialog )(
		0,
		hInst,
		L"",
		L"",
		L"",
		0,
		0,
		0
		);//*/
	//TaskDialog( 0,0,0,0,0,0,0,0 );
	//MessageBox(0,"","",0);
/*	if( TaskDialog != 0 ){
		hInst = 0;
		return;
	}//*/
	if(hInst){
		[](){
		/*	TaskDialog(
				0,
				0,//hInst,
				L"abc",
				0,
				L"cde",
				0,
				0,//TD_WARNING_ICON,
				0
				);//*/
		}();
	}
	MessageBox( 0,
		hxdw_StrPrintf("[%s]\n\n""Build: %a\n", {
			Prf2->srSelfDllBaseName,
			hxdw_GetDateAtCompileTime(""),
		}).c_str(),
		Prf2->srAppName.c_str(),
		MB_ICONINFORMATION|MB_YESNOCANCEL );
}
