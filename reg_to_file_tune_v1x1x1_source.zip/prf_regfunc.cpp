#include "prf_regfunc.h"
//#include <cctype>  //std::tolower()
#include <assert.h>
#include <limits>  //std::numeric_limits
#include "detours.h"
//#include "MinHook.h"
#include "hxdw_process.h"
#include "hxdw_detours_misc.h"
#include "hxdw_utils.h"
#include "prf_utils.h"
#include "prf_apimgr.h"
/*
BOOL __stdcall Prf_PeekMessageA( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg )
{
	assert( Prf2->PeekMessageA );
	//MessageBox( 0, "Prf_PeekMessageA", "PRF", 0);
	hxdw_StdPrint3("PRF: Prf_PeekMessageA(%a,%a,,)...\n", { (int64_t)(size_t)msg, (int64_t)hw2,} );

	using fn_t = decltype(Prf_PeekMessageA)*;
	BOOL rs2 = ((fn_t)Prf2->PeekMessageA)(
		msg, hw2, wMsgFilterMin, wMsgFilterMax, wRemoveMsg );
	return rs2;
}//*/
LONG __stdcall Prf_RegCreateKeyExA(
		HKEY hKey, const char* lpSubKey, DWORD Reserved2, const char* lpClass, DWORD dwOptions,
		REGSAM samDesired, LPSECURITY_ATTRIBUTES lpSecurityAttributes, PHKEY phkResult,
		LPDWORD lpdwDisposition )
{
	using fn_t = decltype(Prf_RegCreateKeyExA)*;
	auto rsx2 = Prf2->am2.findOriginalFunc2( Prf_RegCreateKeyExA );
	assert( +rsx2 );
	fn_t lpOriginal3 = (fn_t)+rsx2;

	bool bTrack2 = 0; std::string srKPath2;
	if( lpSubKey&& *lpSubKey&& phkResult&& *Prf2->rt2.testPathForDetour( hKey, lpSubKey, nullptr, &srKPath2 ) ){
		bTrack2 = 1;
	}
	if( Prf2->bShowRegOpeners ){
		hxdw_StdPrint3(
			"Prf_RegCreateKeyExA(%a,'%a',,'%a',,,), bTrack2:%a\n", {
				PrfRegRootKeyToStr( hKey, "" ),
				( lpSubKey ? lpSubKey : "<null2>" ),
				( !lpClass ? "<null3>" : ( *lpClass ? lpClass : "<len-0>" ) ),
				bTrack2,});
	}
	//if( lpSubKey && *lpSubKey && *Prf2->rt2.testPathForDetour( hKey, lpSubKey, nullptr, &srKPath2 ) && phkResult ){}
	if( bTrack2 ){
		PrfCrKey2 ck2;
		ck2.srKPath3         = srKPath2;
		ck2.lpdwDisposition2 = lpdwDisposition;
		ck2.phKeyOut2        = phkResult;
		auto res3 = Prf2->rt2.createRegKey2( ck2 );
		return +res3;
	}else{
		//LONG rs2 = ((fn_t) +rsx2 )()
		LONG rs2 = ( lpOriginal3 )(
			hKey, lpSubKey, Reserved2, lpClass, dwOptions, samDesired,
			lpSecurityAttributes, phkResult, lpdwDisposition );
		if( rs2 == ERROR_SUCCESS && *phkResult ){
			Prf2->rt2.addKeyForTracking2( hKey, lpSubKey, *phkResult, PRF_ETrkOnCreateKey, nullptr, nullptr );
		}
		return rs2;
	}
}
LONG __stdcall Prf_RegCreateKeyExW( HKEY hKey, const wchar_t* lpSubKey,
	DWORD Reserved2, const wchar_t* lpClass, DWORD dwOptions, REGSAM samDesired,
	LPSECURITY_ATTRIBUTES lpSecurityAttributes, PHKEY phkResult, LPDWORD lpdwDisposition )
{
	std::string srSubKey = ( lpSubKey ? hxdw_StrWcsToUtf8a( lpSubKey, -1 ).c_str() : "");
	std::string srClass = ( lpClass ? hxdw_StrWcsToUtf8a( lpClass, -1 ).c_str() : "");
	return Prf_RegCreateKeyExA( hKey,
			( lpSubKey ? srSubKey.c_str() : nullptr ), Reserved2,
			( lpClass ? srClass.c_str() : nullptr ),
			dwOptions, samDesired, lpSecurityAttributes,
			phkResult, lpdwDisposition );
}
LONG __stdcall Prf_RegOpenKeyExA( HKEY hKey, const char* lpSubKey, DWORD ulOptions,
		REGSAM samDesired, PHKEY phkResult )
{
	using fn_t = decltype(Prf_RegOpenKeyExA)*;
	//assert( Prf2->RegOpenKeyExA );
	auto rsx2 = Prf2->am2.findOriginalFunc2( Prf_RegOpenKeyExA );
	assert( +rsx2 );
	fn_t lpOriginal3 = (fn_t)+rsx2;

	bool bTrack3 = 0;
	std::string srKPath2;
	if( lpSubKey&& *lpSubKey&& phkResult&& *Prf2->rt2.testPathForDetour( hKey, lpSubKey, nullptr, &srKPath2 ) ){
		bTrack3 = 1;
	}
	if( Prf2->bShowRegOpeners ){
		hxdw_StdPrint3("Prf_RegOpenKeyExA(%a,'%a',,,), bTrack3:%a\n", {
				PrfRegRootKeyToStr( hKey, "" ),
				( lpSubKey ? lpSubKey : "<null2>" ),
				bTrack3,});
	}
	if( bTrack3 ){
		PrfOpenKey2 nk2;
		nk2.srKPath3  = srKPath2;
		nk2.phKeyOut2 = phkResult;
		auto res4 = Prf2->rt2.openRegKey2( nk2 );
		return +res4;
	}else{
		LONG rs2 = ((fn_t)lpOriginal3)( hKey, lpSubKey, ulOptions,
			samDesired, phkResult );
		if( rs2 == ERROR_SUCCESS ){
			Prf2->rt2.addKeyForTracking2( hKey, lpSubKey, *phkResult, 0u, nullptr, nullptr );
		}
		return rs2;
	}
}
LONG __stdcall Prf_RegOpenKeyExW( HKEY hKey, const wchar_t* lpSubKey, DWORD ulOptions,
		REGSAM samDesired, PHKEY phkResult )
{
	std::string srSubKey = ( lpSubKey ? hxdw_StrWcsToUtf8a( lpSubKey, -1 ).c_str() : "");
	return Prf_RegOpenKeyExA(
		hKey,
		( lpSubKey ? srSubKey.c_str() : nullptr ),
		ulOptions, samDesired, phkResult
	 );
}
LONG __stdcall Prf_RegSetValueExA( HKEY hKey, const char* lpValueName, DWORD Reserved2,
		DWORD dwType, const uint8_t* lpData, DWORD cbData )
{
	using fn_t = decltype(Prf_RegSetValueExA)*;
	//assert( Prf2->RegSetValueExA );
	auto rsx2 = Prf2->am2.findOriginalFunc2( Prf_RegSetValueExA );
	assert( +rsx2 );
	fn_t lpOriginal3 = (fn_t)+rsx2;

	if( Prf2->bShowRegSetters ){
		hxdw_StdPrint3("Prf_RegSetValueExA(%a,'%a',,%a(%a),,,)\n", {
				PrfRegRootKeyToStr( hKey, "" ),
				( lpValueName ? lpValueName : "<null2>" ),
				PrfRegDataTypeToStr2(dwType,""),
				dwType,});
	}
	// Prf_RegSetValueExA(<unknown_3gYGTo>,'FolderShortcuts',,REG_BINARY(3),,,)
	// Prf_RegSetValueExA(<unknown_3gYGTo>,'PanelPath0',,     REG_SZ(1),,,)
	// Prf_RegSetValueExA(<unknown_3gYGTo>,'FlatViewArc0',,   REG_DWORD(4),,,)
	auto res2 = Prf2->rt2.isKeyTracked2( hKey );
	if( *res2 && +res2 ){
		if( !lpData ){
			//ERROR_INVALID_FUNCTION//ERROR_INVALID_DATA
			return ERROR_INVALID_PARAMETER;
		}
		PrfSetVal2 sv2;
		sv2.hKey        = hKey;
		sv2.szValueName = ( lpValueName ? lpValueName : "" );
		sv2.dwType      = dwType;
		sv2.lpData      = lpData;
		sv2.cbData      = cbData;
		auto res3 = Prf2->rt2.setRegValue2( sv2 );
		return +res3;
	}else{
		LONG rs2 = ((fn_t)lpOriginal3)( hKey, lpValueName, Reserved2,
			dwType, lpData, cbData );
		return rs2;
	}
}
LONG __stdcall Prf_RegSetValueExW( HKEY hKey, const wchar_t* lpValueName, DWORD Reserved2,
		DWORD dwType, const uint8_t* lpData, DWORD cbData )
{
	std::string srValueName = ( lpValueName ? hxdw_StrWcsToUtf8a( lpValueName, -1 ).c_str() : "");
	if( lpData && ( hxdw_Any<DWORD>( dwType, {REG_SZ,REG_EXPAND_SZ,REG_MULTI_SZ,}))){
		std::string srData = hxdw_StrWcsToUtf8a( (wchar_t*)lpData, (cbData/sizeof(wchar_t)) );
		return Prf_RegSetValueExA( hKey, srValueName.c_str(), Reserved2, dwType, (uint8_t*)srData.c_str(), srData.size() );
	}else{
		return Prf_RegSetValueExA( hKey, srValueName.c_str(), Reserved2, dwType, lpData, cbData );
	}
}
LONG __stdcall Prf_RegQueryValueExA(
		HKEY hKey, const char* lpValueName, DWORD* lpReserved,
		DWORD* lpType, uint8_t* lpData, DWORD* lpcbData )
{
	using fn_t = decltype(Prf_RegQueryValueExA)*;
//	assert( Prf2->RegQueryValueExA );
	auto rsx2 = Prf2->am2.findOriginalFunc2( Prf_RegQueryValueExA );
	assert( +rsx2 );
	fn_t lpOriginal3 = (fn_t)+rsx2;


	auto res2 = Prf2->rt2.isKeyTracked2( hKey );
	if( Prf2->bShowRegGetters ){
		hxdw_StdPrint3("Prf_RegQueryValueExA(%a,'%a',,,); tracked:%a(%a)\n", {
				PrfRegRootKeyToStr( hKey, "" ),
				( lpValueName ? lpValueName : "<null2>" ),
				*res2, +res2,});
	}
	if( *res2 && +res2 ){
		PrfGetVal2 gv2;
		gv2.hKey        = hKey;
		gv2.szValueName = lpValueName;
		gv2.lpType      = lpType;
		gv2.lpData      = lpData;
		gv2.lpcbData    = lpcbData;
		auto res3 = Prf2->rt2.getRegValue2( gv2 );
		//hxdw_StdPrint3("x.getRegValue2(,,%a,,) -> %a,%a\n", {
		//		( lpValueName ? lpValueName : "<null2>" ),
		//		*res3, +res3,});//*/
		return +res3;
	}else{
		LONG rs2 = ( lpOriginal3 )(
			hKey, lpValueName, lpReserved,
			lpType, lpData, lpcbData );
		return rs2;
	}
}
LONG __stdcall Prf_RegQueryValueExW(
		HKEY hKey, const wchar_t* lpValueName, DWORD* lpReserved,
		DWORD* lpType,
		uint8_t* lpData,
		DWORD* lpcbData )
{
	std::string srValueName = ( lpValueName ? hxdw_StrWcsToUtf8a( lpValueName, -1 ) : "");
	DWORD uBfrSize = ( lpcbData ? *lpcbData : 0 );

	LONG rs2 = Prf_RegQueryValueExA(
			hKey, const_cast<char*>(srValueName.c_str()),
			lpReserved, lpType, lpData, lpcbData );
	if( lpType && (rs2 == ERROR_SUCCESS || rs2 == ERROR_MORE_DATA) && ( *lpType == REG_SZ || *lpType == REG_EXPAND_SZ || *lpType == REG_MULTI_SZ)){
		if( lpData && lpcbData ){
			std::wstring sr2 = hxdw_StrUtf8aToWcs( (const char*)lpData, (int) *lpcbData );
			*lpcbData = ( sr2.size() * sizeof(wchar_t) );
			if( uBfrSize < *lpcbData ){
				return ERROR_MORE_DATA;
			}
			memcpy( lpData, sr2.c_str(), *lpcbData );
		}else if( lpcbData ){
			*lpcbData = ( *lpcbData * sizeof(wchar_t) );
		}
	}
	return rs2;
}
LONG __stdcall Prf_RegCloseKey( HKEY hKey )
{
	using fn_t = decltype(Prf_RegCloseKey)*;
//	assert( Prf2->RegCloseKey );
	auto rsx2 = Prf2->am2.findOriginalFunc2( Prf_RegCloseKey );
	assert( +rsx2 );
	fn_t lpOriginal3 = (fn_t)+rsx2;

	if( Prf2->bShowRegClose ){
		hxdw_StdPrint3("Prf_RegCloseKey(%a)\n", {
				PrfRegRootKeyToStr( hKey, "" ),
				});//*/
	}
	auto res2 = Prf2->rt2.closeRegKeyIf2( hKey, "");
	if( *res2 && +res2 ){
		return ERROR_SUCCESS;
	}
	LONG rs2 = ( lpOriginal3 )( hKey );
	return rs2;
}
LONG __stdcall Prf_RegEnumKeyExA(
	HKEY hKey, DWORD dwIndex, char* lpName, DWORD* lpcbName,
	DWORD* lpReserved, char* lpClass, DWORD* lpcbClass, PFILETIME lpftLastWriteTime )
{
	using fn_t = decltype(Prf_RegEnumKeyExA)*;
//	assert( Prf2->RegEnumKeyExA );
	auto rsx2 = Prf2->am2.findOriginalFunc2( Prf_RegEnumKeyExA );
	assert( +rsx2 );
	fn_t lpOriginal3 = (fn_t)+rsx2;

	if( !PrfRegValidateRegEnumKeyExParams<char>( { lpName, lpcbName, lpClass, lpcbClass,})){
		return ERROR_INVALID_PARAMETER;
	}
	if( Prf2->bShowRegEnumerators ){
		hxdw_StdPrint3("Prf_RegEnumKeyExA(%a,%a,,,)\n", {
				PrfRegRootKeyToStr( hKey, "" ), dwIndex,});
	}
	auto res2 = Prf2->rt2.isKeyTracked2( hKey );
	if( *res2 && +res2 ){
		PrfEnumKey2 ek2;
		ek2.hKey     = hKey;
		ek2.dwIndex  = dwIndex;
		ek2.lpName   = lpName;
		ek2.lpcbName = lpcbName;
		auto res3 = Prf2->rt2.getRegKeyEnumInfoAtIndex2( ek2 );
		return +res3;
	}
	LONG rs2 = ( lpOriginal3 )(
			hKey, dwIndex, lpName, lpcbName,
			lpReserved, lpClass, lpcbClass, lpftLastWriteTime );
	return rs2;
}
LONG __stdcall Prf_RegEnumKeyExW(
		HKEY hKey, DWORD dwIndex, wchar_t* lpNameOut, DWORD* lpcbNameIO,
		DWORD* lpReserved, wchar_t* lpClassOut, DWORD* lpcbClassIO,
		PFILETIME lpftLastWriteTime )
{
	if( !PrfRegValidateRegEnumKeyExParams<wchar_t>( { lpNameOut, lpcbNameIO, lpClassOut, lpcbClassIO,})){
		return ERROR_INVALID_PARAMETER;
	}
	std::vector<char> aNameBfr, aClassBfr;
	const size_t uInpNameBfrSize = *lpcbNameIO;
	const size_t uInpClassBfrSize = ( lpcbClassIO ? *lpcbClassIO : 0 );
	aNameBfr.resize( size_t(uInpNameBfrSize * 1.5f), 0 );
	if( lpClassOut && lpcbClassIO ){
		aClassBfr.resize( size_t(uInpClassBfrSize * 1.5f), 0 );
	}
	LONG rs2 = Prf_RegEnumKeyExA(
			hKey, dwIndex,
			( !aNameBfr.empty() ? &aNameBfr[0] : nullptr ),//lpNameOut
			lpcbNameIO, lpReserved,
			( !aClassBfr.empty() ? &aClassBfr[0] : nullptr ),//lpClassOut
			lpcbClassIO, lpftLastWriteTime );
	if( rs2 == ERROR_SUCCESS ){
		{
			std::wstring sr2 = hxdw_StrUtf8aToWcs( ( !aNameBfr.empty() ? &aNameBfr[0] : ""), -1 );
			const size_t uNumToCpy = sr2.size() + 1;
			if( uInpNameBfrSize < uNumToCpy ){
				*lpcbNameIO = sr2.size();
				return ERROR_MORE_DATA;
			}
			memcpy( lpNameOut, sr2.c_str(), (uNumToCpy * sizeof(wchar_t)) );
		}
		if( lpClassOut ){
			std::wstring sr2 = hxdw_StrUtf8aToWcs( ( !aClassBfr.empty() ? &aClassBfr[0] : ""), -1 );
			if( uInpClassBfrSize >= sr2.size() + 1 ){
				memcpy( lpClassOut, sr2.c_str(), ( (sr2.size() + 1) * sizeof(wchar_t)));
			}
		}
	}
	return rs2;
}
LONG __stdcall Prf_RegDeleteValueA( HKEY hKey, const char* lpValueName )
{
	using fn_t = decltype(Prf_RegDeleteValueA)*;
	//assert( Prf2->RegDeleteValueA );
	auto rsx2 = Prf2->am2.findOriginalFunc2( Prf_RegDeleteValueA );
	assert( +rsx2 );
	fn_t lpOriginal3 = (fn_t)+rsx2;

	if( Prf2->bShowRegDeleters ){
		hxdw_StdPrint3("Prf_RegDeleteValueA(%a,%a)\n", {
				PrfRegRootKeyToStr( hKey, "" ),
				(lpValueName ? lpValueName : "<null2>"),});
	}
	if( !lpValueName || !*lpValueName ){
		// Ref: if NULL or an empty string, the value set by the RegSetValueEx
		//      function is removed.
		;
	}
	//Prf2->nCalls3 += 1;
	//if( Prf2->nCalls3 <= 1 ){
	//	MessageBox( 0, "Prf_RegDeleteValueA() first.", Prf2->srSelfDllBaseName.c_str(), 0 );
	//}
	LONG rs2 = ( lpOriginal3 )( hKey, lpValueName );
	return rs2;
}
LONG __stdcall Prf_RegDeleteValueW( HKEY hKey, const wchar_t* lpValueName )
{
	std::string srValueName = hxdw_StrWcsToUtf8a( (lpValueName ? lpValueName : L""), -1 );
	return Prf_RegDeleteValueA( hKey, srValueName.c_str() );
}
LONG __stdcall Prf_RegDeleteKeyA( HKEY hKey, const char* lpSubKey )
{
	//Prf2->nCalls4 += 1;
	//if( Prf2->nCalls4 <= 1 ){
	//	MessageBox( 0, "Prf_RegDeleteKeyA() first.", Prf2->srSelfDllBaseName.c_str(), 0 );
	//}
	const REGSAM nKeyWowXx = ( sizeof(size_t) == 4 ? KEY_WOW64_32KEY : KEY_WOW64_64KEY );
	return Prf_RegDeleteKeyExA( hKey, lpSubKey, nKeyWowXx, 0 );
}
LONG __stdcall Prf_RegDeleteKeyW( HKEY hKey, const wchar_t* lpSubKey )
{
	const REGSAM nKeyWowXx = ( sizeof(size_t) == 4 ? KEY_WOW64_32KEY : KEY_WOW64_64KEY );
	return Prf_RegDeleteKeyExW( hKey, lpSubKey, nKeyWowXx, 0 );
}
LONG __stdcall Prf_RegDeleteKeyExA( HKEY hKey, const char* lpSubKey, REGSAM samDesired, DWORD Reserved2 )
{
	using fn_t = decltype(Prf_RegDeleteKeyExA)*;
	//assert( Prf2->RegDeleteKeyExA );
	auto rsx2 = Prf2->am2.findOriginalFunc2( Prf_RegDeleteKeyExA );
	assert( +rsx2 );
	fn_t lpOriginal3 = (fn_t)+rsx2;

	//Prf2->nCalls5 += 1;
	//if( Prf2->nCalls5 <= 1 ){
	//	MessageBox( 0, "Prf_RegDeleteKeyExA() first.", Prf2->srSelfDllBaseName.c_str(), 0 );
	//}
	if( Prf2->bShowRegDeleters ){
		hxdw_StdPrint3("Prf_RegDeleteKeyExA(%a,%a)\n", {
				PrfRegRootKeyToStr( hKey, "" ),
				(lpSubKey ? lpSubKey : "<null2>"),});
	}
	std::string srKPath2;
	auto res2 = Prf2->rt2.testPathForDetour( hKey, lpSubKey, nullptr, &srKPath2 );
	if( *res2 && +res2 ){
		PrfDelKey2 dk2;
		dk2.hKey     = hKey;
		dk2.lpSubKey = lpSubKey;
		dk2.srKPath3 = srKPath2;
		auto res3 = Prf2->rt2.deleteRegKey2( dk2 );
		return +res3;
	}
	LONG rs2 = ( lpOriginal3 )( hKey, lpSubKey, samDesired, Reserved2 );
	return rs2;
}
LONG __stdcall Prf_RegDeleteKeyExW( HKEY hKey, const wchar_t* lpSubKey, REGSAM samDesired, DWORD Reserved2 )
{
	std::string srSubKey = hxdw_StrWcsToUtf8a( (lpSubKey ? lpSubKey : L""), -1 );
	return Prf_RegDeleteKeyExA( hKey, (lpSubKey ? srSubKey.c_str() : nullptr), samDesired, Reserved2 );
}

LONG __stdcall Prf_RegCreateKeyA( HKEY hKey, const char* lpSubKey, PHKEY phkResult )
{
	LONG rs2 = Prf_RegCreateKeyExA( hKey, lpSubKey,
		0, //Reserved_
		nullptr, //lpClass
		0u,//dwOptions : DWORD
		0, //samDesired : REGSAM
		nullptr,//lpSecurityAttributes : SECURITY_ATTRIBUTES*
		phkResult,
		nullptr//lpdwDisposition : DWORD*
		);
	return rs2;
}
LONG __stdcall Prf_RegCreateKeyW( HKEY hKey, const wchar_t* lpSubKey, PHKEY phkResult )
{
	LONG rs2 = Prf_RegCreateKeyExW( hKey, lpSubKey,
			0, nullptr, 0u, 0, nullptr, phkResult, nullptr );
	return rs2;
}
LONG __stdcall Prf_RegOpenKeyA( HKEY hKey, const char* lpSubKey, PHKEY phkResult )
{
	return Prf_RegOpenKeyExA( hKey, lpSubKey, 0, 0, phkResult );
}
LONG __stdcall Prf_RegOpenKeyW( HKEY hKey, const wchar_t* lpSubKey, PHKEY phkResult )
{
	return Prf_RegOpenKeyExW( hKey, lpSubKey, 0, 0, phkResult );
}
template<class Tch>
LONG __stdcall
Prf_RegQueryValueTAW( HKEY hKey, const Tch* lpSubKey, Tch* lpData, LONG* lpcbData )
{
	static_assert( sizeof(DWORD) == sizeof(LONG), "");
	if( lpcbData && *lpcbData < 0 ){
		return ERROR_INVALID_PARAMETER;
	}
	DWORD dwData = ( lpcbData ? (DWORD) *lpcbData : 0 );
	LONG rs2;
	if( std::is_same<Tch,wchar_t>::value ){
		rs2 = Prf_RegQueryValueExW( hKey, (wchar_t*) lpSubKey,
				0, nullptr, (uint8_t*)lpData, ( lpcbData ? &dwData : nullptr ) );
	}else{
		rs2 = Prf_RegQueryValueExA( hKey, (char*) lpSubKey,
				0, nullptr, (uint8_t*)lpData, ( lpcbData ? &dwData : nullptr ) );
	}
	if( lpcbData ){
		*lpcbData = static_cast<LONG>(
			std::min( dwData, (static_cast<DWORD>( std::numeric_limits<LONG>::max()))));
	}
	return rs2;
}
// Explicit instantiations
template LONG Prf_RegQueryValueTAW<char>( HKEY hKey, const char* lpSubKey, char* lpData, LONG* lpcbData );
template LONG Prf_RegQueryValueTAW<wchar_t>( HKEY hKey, const wchar_t* lpSubKey, wchar_t* lpData, LONG* lpcbData );

LONG __stdcall Prf_RegSetValueA( HKEY hKey,
		const char* lpSubKey, DWORD dwType, const char* lpData, DWORD cbData )
{
	return Prf_RegSetValueExA( hKey, lpSubKey, 0, dwType, (const uint8_t*)lpData, cbData );
}
LONG __stdcall Prf_RegSetValueW( HKEY hKey,
	const wchar_t* lpSubKey, DWORD dwType, const wchar_t* lpData, DWORD cbData )
{
	return Prf_RegSetValueExW( hKey, lpSubKey, 0, dwType, (const uint8_t*)lpData, cbData );
}
LONG __stdcall Prf_RegEnumKeyA( HKEY hKey, DWORD dwIndex, char* lpName, DWORD cchName )
{
	if( !lpName || !cchName ){
		return ERROR_INVALID_PARAMETER;
	}
	char bfr2[512] = "";
	DWORD dwLenName2 = ( sizeof(bfr2) / sizeof(bfr2[0]) );
	LONG rs2 = Prf_RegEnumKeyExA( hKey, dwIndex, bfr2, &dwLenName2, 0, nullptr, 0, nullptr );
	if( rs2 == ERROR_SUCCESS ){
		// The function copies only the name of the subkey, not the full key hierarchy, to the buffer.
		std::string srVarname = bfr2;
		if( hxdw_IsWithPathPart( srVarname.c_str() ) ){
			srVarname = hxdw_SplitPath( srVarname ).second;
		}
		if( cchName < srVarname.size()+1 ){
			return ERROR_MORE_DATA;
		}
		memcpy( lpName, srVarname.c_str(), srVarname.size()+1 );
	}else if( rs2 == ERROR_MORE_DATA ){
		return ERROR_INVALID_DATA;
	}
	return rs2;
}
LONG __stdcall Prf_RegEnumKeyW( HKEY hKey, DWORD dwIndex, wchar_t* lpName, DWORD cchName )
{
	if( !lpName || !cchName ){
		return ERROR_INVALID_PARAMETER;
	}
	std::vector<char> bfr3;
	bfr3.resize( size_t(cchName * 1.5f), 0 );

	LONG rs2 = Prf_RegEnumKeyA( hKey, dwIndex, &bfr3[0], bfr3.size() );
	if( rs2 == ERROR_SUCCESS ){
		assert( bfr3.size() >= cchName );
		std::wstring sr2 = hxdw_StrUtf8aToWcs( bfr3.data(), -1 );
		if( cchName < sr2.size()+1 ){
			return ERROR_MORE_DATA;
		}
		memcpy( lpName, sr2.c_str(), ( (sr2.size()+1) * sizeof(sr2[0]) ) );
	}
	return rs2;
}

bool PrfRegDetoursInit()
{
	//LONG rs2; int nCntRegFnc = 0;
//	bool bSuccess2 = 1L;
	DetourTransactionBegin();
	DetourUpdateThread( GetCurrentThread() );
	std::shared_ptr<void*> raii2( nullptr, [&]( void* ){
		DetourTransactionCommit();
	});
	//HMODULE hUser32Dll = 0, hAdvapi32Dll = 0;
	{
	/*	hxdw_EnumerateProcessModules( 0, [&]( const HxdwModOnEnum& inp )->bool{
				auto bn2 = hxdw_SplitPath( inp.srPath ).second;
				assert( !bn2.empty() );
				if( !hUser32Dll && !hxdw_StrCmpOpt3( bn2.c_str(), "user32.dll", -1, "i" ) ){
					hUser32Dll = (HMODULE)inp.hDll;
				}
				if( !hAdvapi32Dll && !hxdw_StrCmpOpt3( bn2.c_str(), "advapi32.dll", -1, "i" ) ){
					hAdvapi32Dll = (HMODULE)inp.hDll;
				}
				return 1L;
			});
		assert( hUser32Dll );//*/
	}{
	/*	LONG rs2 = hxdw_DetourAttach3( hUser32Dll, nullptr, "PeekMessageA",
				&Prf2->PeekMessageA, Prf_PeekMessageA, 0,
				DetourAttach );
		if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
			std::string msg2 = hxdw_DetoursErrorToString( rs2 );
			hxdw_StdPrint3(
				"PRF: ERROR: Detouring PeekMessageA failed. Code:[%d:%s] [jBsdfC]\n",
				{ (int)rs2, msg2.c_str(),});
			bSuccess2 = 0L;
		}//*/
	}
	if( 000 ){ //hAdvapi32Dll
		//hxdw_StdPrint3("PRF: Detouring Advapi32.dll functions.\n", {});
		{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegCreateKeyExA",
					&Prf2->RegCreateKeyExA, Prf_RegCreateKeyExA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegCreateKeyExA failed. Code:[%d:%s] [lOS7Jg]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegCreateKeyExW",
					&Prf2->RegCreateKeyExW, Prf_RegCreateKeyExW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegCreateKeyExW failed. Code:[%d:%s] [ZuE6wS]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegOpenKeyExA",
					&Prf2->RegOpenKeyExA, Prf_RegOpenKeyExA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegOpenKeyExA failed. Code:[%d:%s] [xDI9Dc]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegOpenKeyExW",
					&Prf2->RegOpenKeyExW, Prf_RegOpenKeyExW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegOpenKeyExW failed. Code:[%d:%s] [9yPyW4]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegSetValueExA",
					&Prf2->RegSetValueExA, Prf_RegSetValueExA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegSetValueExA failed. Code:[%d:%s] [9yPyW4]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegSetValueExW",
					&Prf2->RegSetValueExW, Prf_RegSetValueExW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegSetValueExW failed. Code:[%d:%s] [ckn9Uw]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegQueryValueExA",
					&Prf2->RegQueryValueExA, Prf_RegQueryValueExA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegQueryValueExA failed. Code:[%d:%s] [NV3GxB]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegQueryValueExW",
					&Prf2->RegQueryValueExW, Prf_RegQueryValueExW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegQueryValueExW failed. Code:[%d:%s] [m47DHf]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegCloseKey",
					&Prf2->RegCloseKey, Prf_RegCloseKey, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegCloseKey failed. Code:[%d:%s] [iSI65D]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegEnumKeyExA",
					&Prf2->RegEnumKeyExA, Prf_RegEnumKeyExA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegEnumKeyExA failed. Code:[%d:%s] [kSgJyv]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegEnumKeyExW",
					&Prf2->RegEnumKeyExW, Prf_RegEnumKeyExW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegEnumKeyExW failed. Code:[%d:%s] [QyokLo]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegDeleteValueA",
					&Prf2->RegDeleteValueA, Prf_RegDeleteValueA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegDeleteValueA failed. Code:[%d:%s] [YCH4L2]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegDeleteValueW",
					&Prf2->RegDeleteValueW, Prf_RegDeleteValueW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegDeleteValueW failed. Code:[%d:%s] [OoftSP]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegDeleteKeyA",
					&Prf2->RegDeleteKeyA, Prf_RegDeleteKeyA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegDeleteKeyA failed. Code:[%d:%s] [tEqtYt]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegDeleteKeyW",
					&Prf2->RegDeleteKeyW, Prf_RegDeleteKeyW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegDeleteKeyW failed. Code:[%d:%s] [VGlP8o]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegDeleteKeyExA",
					&Prf2->RegDeleteKeyExA, Prf_RegDeleteKeyExA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegDeleteKeyExA failed. Code:[%d:%s] [Y2a2fH]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegDeleteKeyExW",
					&Prf2->RegDeleteKeyExW, Prf_RegDeleteKeyExW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegDeleteKeyExW failed. Code:[%d:%s] [ITAcbS]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegCreateKeyA",
					&Prf2->RegCreateKeyA, Prf_RegCreateKeyA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegCreateKeyA failed. Code:[%d:%s] [wh5See]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegCreateKeyW",
					&Prf2->RegCreateKeyW, Prf_RegCreateKeyW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegCreateKeyW failed. Code:[%d:%s] [aB6QYR]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegOpenKeyA",
					&Prf2->RegOpenKeyA, Prf_RegOpenKeyA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegOpenKeyA failed. Code:[%d:%s] [msxpJE]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegOpenKeyW",
					&Prf2->RegOpenKeyW, Prf_RegOpenKeyW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegOpenKeyW failed. Code:[%d:%s] [H69RTM]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegQueryValueA",
					&Prf2->RegQueryValueA,
					Prf_RegQueryValueTAW<char>,
					0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegQueryValueA failed. Code:[%d:%s] [A7Qnq6]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegQueryValueW",
					&Prf2->RegQueryValueW,
					Prf_RegQueryValueTAW<wchar_t>,
					0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegQueryValueW failed. Code:[%d:%s] [1pv9Bt]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegSetValueA",
					&Prf2->RegSetValueA, Prf_RegSetValueA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegSetValueA failed. Code:[%d:%s] [6pubWF]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegSetValueW",
					&Prf2->RegSetValueW, Prf_RegSetValueW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegSetValueW failed. Code:[%d:%s] [VLhf7w]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}{
		/*	rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegEnumKeyA",
					&Prf2->RegEnumKeyA, Prf_RegEnumKeyA, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegEnumKeyA failed. Code:[%d:%s] [qsrxU0]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}
			rs2 = hxdw_DetourAttach3( hAdvapi32Dll, nullptr, "RegEnumKeyW",
					&Prf2->RegEnumKeyW, Prf_RegEnumKeyW, 0, DetourAttach );
			nCntRegFnc += !rs2;
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				hxdw_StdPrint3("PRF: ERROR: Detouring RegEnumKeyW failed. Code:[%d:%s] [ttqRK9]\n",
					{ (int)rs2, hxdw_DetoursErrorToString( rs2 ),});
				bSuccess2 = 0L;
			}//*/
		}
		//hxdw_StdPrint3("PRF: Detoured %a Reg Winapi functions.\n", { nCntRegFnc,});
	}
	{
		// TODO: move to outside.
		if( Prf2->eSaveINIStrategy & PRF_ESIS_OnProcApiExit ){
			//Prf2->am2.addFuncRefByName2("ExitProcess", "a");
		}
		Prf2->am2.addFuncRefByName2("RegCreateKeyExA", "a");
		Prf2->am2.addFuncRefByName2("RegCreateKeyExW", "a");
		Prf2->am2.addFuncRefByName2("RegOpenKeyExA", "a");
		Prf2->am2.addFuncRefByName2("RegOpenKeyExW", "a");
		Prf2->am2.addFuncRefByName2("RegSetValueExA", "a");
		Prf2->am2.addFuncRefByName2("RegSetValueExW", "a");
		Prf2->am2.addFuncRefByName2("RegQueryValueExA", "a");
		Prf2->am2.addFuncRefByName2("RegQueryValueExW", "a");
		Prf2->am2.addFuncRefByName2("RegCloseKey", "a");
		Prf2->am2.addFuncRefByName2("RegEnumKeyExA", "a");
		Prf2->am2.addFuncRefByName2("RegEnumKeyExW", "a");
		Prf2->am2.addFuncRefByName2("RegDeleteValueA", "a");
		Prf2->am2.addFuncRefByName2("RegDeleteValueW", "a");
		Prf2->am2.addFuncRefByName2("RegDeleteKeyA", "a");
		Prf2->am2.addFuncRefByName2("RegDeleteKeyW", "a");
		Prf2->am2.addFuncRefByName2("RegQueryValueA", "a");
		Prf2->am2.addFuncRefByName2("RegQueryValueW", "a");
		Prf2->am2.addFuncRefByName2("RegOpenKeyA", "a");
		Prf2->am2.addFuncRefByName2("RegOpenKeyW", "a");
		Prf2->am2.addFuncRefByName2("RegDeleteKeyExA", "a");
		Prf2->am2.addFuncRefByName2("RegDeleteKeyExW", "a");
		Prf2->am2.addFuncRefByName2("RegCreateKeyA", "a");
		Prf2->am2.addFuncRefByName2("RegCreateKeyW", "a");
		Prf2->am2.addFuncRefByName2("RegSetValueA", "a");
		Prf2->am2.addFuncRefByName2("RegSetValueW", "a");
		Prf2->am2.addFuncRefByName2("RegEnumKeyA", "a");
		Prf2->am2.addFuncRefByName2("RegEnumKeyW", "a");
		Prf2->am2.unfoldApiDetours();//PrfApiDtrMgr
	}
	//hxdw_StdPrint3("PRF: PrfRegDetoursInit() done. -> %a\n", { bSuccess2,});
	return 1L;
}
