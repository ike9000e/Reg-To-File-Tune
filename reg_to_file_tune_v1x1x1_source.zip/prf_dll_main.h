#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
//#define _USING_V110_SDK71_ 1
#include <windows.h>
#include <assert.h>
//#include <stdio.h>
//#include <ctime> //std::time()
//#include <mmsystem.h>   //PlaySound()
//#include "MinHook.h"
#include "hxdw_utils.h"
#include "prf_utils.h"
#include "prf_regfunc.h"
#include <cctype>  //std::tolower()
//#include <commctrl.h>
//#include <Shellapi.h>
//#include <xinput.h>   //XInputGetState()
#include "detours.h"
#include "hxdw_process.h"
#include "hxdw_detours_misc.h"

BOOL WINAPI DllMain( HINSTANCE hInst, DWORD dwReason, LPVOID );

/*
	/EHsc
	/O1
	/FS
	/MP1
	/GL-
	/MT
	"/D" WIN32_LEAN_AND_MEAN
	"/D" _WIN32_WINNT=0x501
	"/D" _USING_V110_SDK71_
	"/D" NOMINMAX
	---
	"/D" NOMINMAX
	"/D" _WIN32_WINNT=0x0A00
	"/D" WINVER=0x0A00
	"/D" NTDDI_VERSION=0x06010000
	---
	comctl32
*/
