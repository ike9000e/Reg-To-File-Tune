#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
//#define _USING_V110_SDK71_ 1

//void x(){
//	std::numeric_limits<LONG>::max();
//}
#include <windows.h>
#include <inttypes.h>   //uint8_t

//UrlEscapeA()

// 7zip FM (7zFM.exe) imports:
// va  RegCreateKeyExW, +RegCreateKeyExA
// va  RegOpenKeyExA, RegOpenKeyExW
// va  RegQueryValueExA, RegQueryValueExW
// va  RegCloseKey,
// va  RegEnumKeyExW, +RegEnumKeyExA
//     - in 7zFM.exe, seems never called.
// va  RegSetValueExW, +RegSetValueExA
// _a  RegDeleteValueW, +RegDeleteValueA
// va  RegDeleteKeyW, +RegDeleteKeyA
//
// related imports:
// va  RegDeleteKeyExA, RegDeleteKeyExW

// CFF_Explorer_VIII new vs 7zip imports:
// va  RegCreateKeyW, +RegCreateKeyA
// va  RegOpenKeyW, +RegOpenKeyA
// va  RegQueryValueW, +RegQueryValueA
// va  RegSetValueW, +RegSetValueA
// va  RegEnumKeyW, +RegEnumKeyA


bool PrfRegDetoursInit();

// REF:
// * Registry value types - Win32 apps Microsoft Learn.htm
//   https://learn.microsoft.com/en-us/windows/win32/sysinfo/registry-value-types
// * System Error Codes (0-499) (WinError.h) - Win32 apps Microsoft Learn.htm
//   https://learn.microsoft.com/en-us/windows/win32/debug/system-error-codes--0-499-
// * Tutorial - Debug system error codes - Win32 apps Microsoft Learn.htm
//   https://learn.microsoft.com/en-us/windows/win32/debug/system-error-codes

LONG __stdcall Prf_RegCreateKeyExA(
		HKEY hKey, const char* lpSubKey, DWORD Reserved2, const char* lpClass, DWORD dwOptions,
		REGSAM samDesired, LPSECURITY_ATTRIBUTES lpSecurityAttributes, PHKEY phkResult,
		LPDWORD lpdwDisposition );
LONG __stdcall Prf_RegCreateKeyExW( HKEY hKey, const wchar_t* lpSubKey,
		DWORD Reserved2, const wchar_t* lpClass, DWORD dwOptions, REGSAM samDesired,
		LPSECURITY_ATTRIBUTES lpSecurityAttributes, PHKEY phkResult, LPDWORD lpdwDisposition );

LONG __stdcall Prf_RegOpenKeyExA( HKEY hKey, const char* lpSubKey, DWORD ulOptions,
		REGSAM samDesired, PHKEY phkResult );
LONG __stdcall Prf_RegOpenKeyExW( HKEY hKey, const wchar_t* lpSubKey, DWORD ulOptions,
		REGSAM samDesired, PHKEY phkResult );

LONG __stdcall Prf_RegSetValueExA( HKEY hKey, const char* lpValueName, DWORD Reserved2,
		DWORD dwType, const uint8_t* lpData, DWORD cbData );
LONG __stdcall Prf_RegSetValueExW( HKEY hKey, const wchar_t* lpValueName, DWORD Reserved2,
		DWORD dwType, const uint8_t* lpData, DWORD cbData );

LONG __stdcall Prf_RegQueryValueExA(
		HKEY hKey, const char* lpValueName, DWORD* lpReserved,
		DWORD* lpType, uint8_t* lpData, DWORD* lpcbData );
LONG __stdcall Prf_RegQueryValueExW(
		HKEY hKey, const wchar_t* lpValueName, DWORD* lpReserved,
		DWORD* lpType, uint8_t* lpData, DWORD* lpcbData );

LONG __stdcall Prf_RegCloseKey( HKEY hKey );

LONG __stdcall Prf_RegEnumKeyExA(
		HKEY hKey, DWORD dwIndex, char* lpName, DWORD* lpcbName,
		DWORD* lpReserved, char* lpClass, DWORD* lpcbClass,
		PFILETIME lpftLastWriteTime );
LONG __stdcall Prf_RegEnumKeyExW(
		HKEY hKey, DWORD dwIndex, wchar_t* lpName, DWORD* lpcbName,
		DWORD* lpReserved, wchar_t* lpClass, DWORD* lpcbClass, PFILETIME lpftLastWriteTime );

LONG __stdcall Prf_RegDeleteValueA( HKEY hKey, const char* lpValueName );
LONG __stdcall Prf_RegDeleteValueW( HKEY hKey, const wchar_t* lpValueName );

LONG __stdcall Prf_RegDeleteKeyA( HKEY hKey, const char* lpSubKey );
LONG __stdcall Prf_RegDeleteKeyW( HKEY hKey, const wchar_t* lpSubKey );

LONG __stdcall Prf_RegDeleteKeyExA( HKEY hKey, const char* lpSubKey, REGSAM samDesired, DWORD Reserved2 );
LONG __stdcall Prf_RegDeleteKeyExW( HKEY hKey, const wchar_t* lpSubKey, REGSAM samDesired, DWORD Reserved2 );

//ERROR_NO_MORE_ITEMS
//ERROR_INVALID_PARAMETER, ERROR_INVALID_DATA
//ERROR_INVALID_FUNCTION, ERROR_INVALID_BLOCK
//ERROR_SUCCESS, ERROR_MORE_DATA

LONG __stdcall Prf_RegOpenKeyA( HKEY hKey, const char* lpSubKey, PHKEY phkResult );
LONG __stdcall Prf_RegOpenKeyW( HKEY hKey, const wchar_t* lpSubKey, PHKEY phkResult );
LONG __stdcall Prf_RegCreateKeyA( HKEY hKey, const char* lpSubKey, PHKEY phkResult );
LONG __stdcall Prf_RegCreateKeyW( HKEY hKey, const wchar_t* lpSubKey, PHKEY phkResult );

LONG __stdcall Prf_RegSetValueA( HKEY hKey,
		const char* lpSubKey, DWORD dwType, const char* lpData, DWORD cbData );
LONG __stdcall Prf_RegSetValueW( HKEY hKey,
	const wchar_t* lpSubKey, DWORD dwType, const wchar_t* lpData, DWORD cbData );
LONG __stdcall Prf_RegEnumKeyA( HKEY hKey, DWORD dwIndex, char* lpName, DWORD cchName );
LONG __stdcall Prf_RegEnumKeyW( HKEY hKey, DWORD dwIndex, wchar_t* lpName, DWORD cchName );

template<class Tch>
LONG __stdcall
Prf_RegQueryValueTAW( HKEY hKey, const Tch* lpSubKey, Tch* lpData, LONG* lpcbData );
